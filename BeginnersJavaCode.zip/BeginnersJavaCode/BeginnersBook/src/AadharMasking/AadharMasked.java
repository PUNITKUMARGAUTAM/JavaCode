package AadharMasking;

public class AadharMasked {
	
//	    public static void main(String[] args) {
//	        String aadhaarNumber = "1234 5678 9012";
//	        String maskedAadhaarNumber = maskAadhaarNumber(aadhaarNumber);
//	        System.out.println(maskedAadhaarNumber); // Output: XXXX XXXX 9012
//	    }
//
//	    public static String maskAadhaarNumber(String aadhaarNumber) {
//	        // Remove all non-digit characters from the Aadhaar number
//	        String digitsOnly = aadhaarNumber.replaceAll("\\D", "");
//
//	        // Replace all but the last four digits with X
//	        String maskedNumber = "";
//	        if (digitsOnly.length() > 4) {
//	            String lastFourDigits = digitsOnly.substring(digitsOnly.length() - 4);
//	            String maskedDigits = digitsOnly.substring(0, digitsOnly.length() - 4).replaceAll(".", "X");
//	            maskedNumber = maskedDigits + lastFourDigits;
//	        } else {
//	            maskedNumber = digitsOnly;
//	        }
//
//	        // Add spaces after every four digits
//	        StringBuilder sb = new StringBuilder(maskedNumber);
//	        for (int i = 4; i < sb.length(); i += 5) {
//	            sb.insert(i, " ");
//	        }
//
//	        return sb.toString();
//	    }
	
	public static String maskAadharNumber(String aadharNumber) {
		String maskAadharNumber=" ";
		if(aadharNumber!=null && aadharNumber.length()==12) {
			String lastFourDigits=aadharNumber.substring(8);
			maskAadharNumber="XXXXXXXX"+lastFourDigits;
		}
		return maskAadharNumber;
		}
	public static void main(String atgs[]) {
		String str = maskAadharNumber("122345679963");
		System.out.println("Aadhar Number Is " + str);
		
	}
	}



