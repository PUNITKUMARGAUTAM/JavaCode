package AadharMasking;

//import fasterxml.jackson.databind.ObjectMapper;
//public class JsonToString {
//	
//	public static void main(String args[]) throws Exception {
//		
//		ObjectMapper mapper = new ObjectMapper();
//		
//		Object json =mapper.readValue("{\"key\":\"value\"}",Object.class);
//		
//		String jsonString =mapper.writeValueAsString(json);
//		
//		System.out.println(jsonString);
//	}
//
//}

//import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonToString {
    public static void main(String[] args) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        Object json = mapper.readValue("{\"key\": \"value\"}", Object.class);
        String jsonString = mapper.writeValueAsString(json);
        System.out.println(jsonString);
    }
}

