package AadharMasking;

public class ObjectMapper {

	

	public String writeValueAsString(Object json) {
		// TODO Auto-generated method stub
		return "\"Name\": \"Punit\"";
	}

	public Object readValue(String string, Class<Object> class1) {
		// TODO Auto-generated method stub
		return null;
	}

}
