package BeginnersBookLearn;

//Narrowing Type Casting
//It is also known as explicit type casting. It is done when assigning a larger size data type to smaller 
//size data type, thus the term narrowing is used.
//
//Notice the int inside parentheses before double variable d and float variable f. 
//This is done when passing the larger size data type value to smaller size data type.

public class Casting {
	public static void main(String args[]) {
		
		double d=1452.56d;
		float f=6467.56f;
		
		int i=(int)d;
		int i2=(int)f;
		
		System.out.println(d);
		System.out.println(f);
		System.out.println(i);
		System.out.println(i2);
		
		
//		Widening Type Casting
//		
//		Widening type casting is an automatic casting. In this type casting, a value of smaller data type 
//		is assigned to larger size data type. This is also called implicit type casting as there is no need 
//		to mention the data type in parentheses and the conversion is handled automatically by the compiler.
		
		int s=1002;
		float p=123.3f;
		
		long l=s;
		double dub=p;
		
		System.out.println("int value: "+s);
		System.out.println("float value: "+p);
		System.out.println("Long value: "+s);
		System.out.println("double value: "+p);
		
	}
	

}
