package BeginnersBookLearn;

public class ControilSwitchCaseStatements {
	
public static void main (String args[]) {
	
//	Switch Case statement is mostly used with break statement even though it is optional. 
//	We will first see an example without break statement and then we will discuss switch case with break
	
//	int num=2;
//	switch(num+2) 
//	{
//	
//	case 1:
//		System.out.println("Case1: value is: "+num);
//	
//	case 2:
//		System.out.println("Case2: value is: "+num);
//	case 3:
//		System.out.println("Case3: value is: "+num);
//	default:
//		System.out.println("Default: value is: "+num);
//		
//	}
	
	
// Example with break statement
	
	int i=3;
	
	switch(i) {
	case 1:
		System.out.println("Case1");
		break;
	case 2:
		System.out.println("Case2");
		break;
	case 3:
		System.out.println("Case3");
		break;
	case 4:
		System.out.println("Case4");
		break;
	default:
		System.out.println("default value");
	}
}
}
