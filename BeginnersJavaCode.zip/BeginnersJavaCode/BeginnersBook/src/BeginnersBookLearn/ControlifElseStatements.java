//The statements gets executed only when the given condition is true. If the condition is false then the statements inside
//if statement body are completely ignored.

package BeginnersBookLearn;

public class ControlifElseStatements {

	public static void main(String args[]) {
		
//		int num=70;
//		if(num < 100) {
//			System.out.println("Number is less than 100");
//		}
		
//Nested if statement in Java
//When there is an if statement inside another if statement then it is called the nested if statement.
//The structure of nested if looks like this:
	
//Statement1 would execute if the condition_1 is true. 
//Statement2 would only execute if both the conditions( condition_1 and condition_2) are true.
		
//		int num1 =70;
//		if(num1 < 100) {
//		System.out.println("Number is less than 100");
//	    if(num1 > 50) {
//		System.out.println("Number is greater than 50");
//		}
//		}
		
//If else statement in Java
		
//The statements inside �if� would execute if the condition is true, 
//and the statements inside �else� would execute if the condition is false.	
		
//		int num2=120;
//		if(num2 < 50) {
//		System.out.println("Number is greater than 50");
//		}
//		else {
//		System.out.println("Number is greater than  or equal 50");
//		}
		
	
//if-else-if Statement
//The most important point to note here is that in if-else-if statement, 
//as soon as the condition is met, the corresponding set of statements get executed, 
//rest gets ignored. If none of the condition is met then the statements inside �else� gets executed.
	
	int num4=1234;
	if(num4 < 100 && num4 >= 1) {
		System.out.println("Its two digit number");
		}
	else if(num4 <1000 && num4 >=100) {
		System.out.println("Its three digit number");
	}
	else if(num4 <10000 && num4 >=1000) {
		System.out.println("Its four digit number");
	}
	else if(num4 <100000 && num4 >=10000) {
		System.out.println("Its five digit number");
	}

	else {
		System.out.println("Number is not between 1 t0 99999");
	}
		
	}
}

