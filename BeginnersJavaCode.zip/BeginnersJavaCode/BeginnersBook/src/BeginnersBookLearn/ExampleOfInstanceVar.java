//Each instance(objects) of class has its own copy of instance variable. Unlike static variable, 
//instance variables have their own separate copy of instance variable. We have changed the instance 
//variable value using object obj2 in the following program and when we displayed the variable using 
//all three objects, only the obj2 value got changed, 
//others remain unchanged. This shows that they have their own copy of instance variable.
package BeginnersBookLearn;

public class ExampleOfInstanceVar {
	
	String myInstanceVar="Instance Variable";
	
	
	public static void main(String args[]) {
		
	
	
	ExampleOfInstanceVar obj=new ExampleOfInstanceVar();
	ExampleOfInstanceVar obj1=new ExampleOfInstanceVar();
	ExampleOfInstanceVar obj2=new ExampleOfInstanceVar();
	
	System.out.println(obj.myInstanceVar);
	System.out.println(obj1.myInstanceVar);
	System.out.println(obj2.myInstanceVar);
	
	
    obj1.myInstanceVar="Changed Text";
	
	System.out.print(obj.myInstanceVar);
	System.out.println(obj1.myInstanceVar);
	System.out.println(obj2.myInstanceVar);
	
	

}
}