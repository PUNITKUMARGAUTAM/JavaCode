//These variables are declared inside method of the class. Their scope is limited to the method 
//which means that You can�t change their values and access them outside of the method.

package BeginnersBookLearn;

public class ExampleOfLocalVar {
	
	//Instance variable
	
	String myVar="Instance variable";
	
	public void myMethod() {
		
		//local variable
		
		String myVar="Inside method";
		System.out.println(myVar);
	}
	
	public static void main(String ags[]) {
		
		//Creating object
	
		ExampleOfLocalVar obj=new ExampleOfLocalVar();
		
		System.out.println("Calling method");
		obj.myMethod();
		System.out.println(obj.myVar);
		
	}
	

}
