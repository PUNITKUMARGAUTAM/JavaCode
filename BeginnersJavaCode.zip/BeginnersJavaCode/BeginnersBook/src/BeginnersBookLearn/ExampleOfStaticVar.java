//Static variables are also known as class variable because they are associated with the class and common 
//for all the instances of class. For example, If I create three objects of a class and access this static 
//variable, it would be common for all, the changes made to the variable using one of the object would reflect
//when you access it through other objects.
package BeginnersBookLearn;

public class ExampleOfStaticVar {

	public static String myClassvar="Static variable or class";
	
	public  static void main(String args[]) {
		
		ExampleOfStaticVar obj= new ExampleOfStaticVar();
		ExampleOfStaticVar obj1= new ExampleOfStaticVar();
		ExampleOfStaticVar obj2= new ExampleOfStaticVar();
		
		
		//All three will display "class or static variable"
		System.out.println(obj.myClassvar);
		System.out.println(obj1.myClassvar);
		System.out.println(obj2.myClassvar);
		
		obj2.myClassvar="ChangedText";
	
		System.out.println(obj.myClassvar);
		System.out.println(obj1.myClassvar);
		System.out.println(obj2.myClassvar);
		
	

		
		
		
		
	}
	}
	


