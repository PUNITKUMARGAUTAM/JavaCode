package BeginnersBookLearn;

class FindNumber {

	public static void main(String[] args) {
//		int x,y;
//		
//		x=10;
//		y=20;
//		
//	System.out.println("Original value");
//	System.out.println("x="+x);
//	System.out.println("y="+y);
//	x=x^y^(y=x);
//	System.out.println("Swap values");
//	System.out.println("x="+x);
//	System.out.println("y="+y);
//	
//		
//		
//	}
		
		 for(int i=10; i<50; i++) {
	            
	            if(i%3==0&&i%2==0) {
	                
	                System.out.println(i);
	              
	            }
		 }
	}
}
//	            if(i%2==0){
//	            	System.out.println(i);
//	            }
//	            	
//	            }
	            	
	            
	        
	    

