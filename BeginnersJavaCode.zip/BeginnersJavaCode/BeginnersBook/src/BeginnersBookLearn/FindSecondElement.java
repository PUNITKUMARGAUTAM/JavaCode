package BeginnersBookLearn;

import java.util.Scanner;

public class FindSecondElement {
	
	public static void main (String args[]){

//		int arr[] = {100,94,23,48,89,39,10};
//        int i=0;
		Scanner sc= new Scanner(System.in);
		System.out.println("The Enter the number is:");
		int arr[]= {};
		int n=0;
		int largest=sc.nextInt();
		int secondLargest=sc.nextInt();
		
		for(int i=0; i<n; i++)
		{
//		System.out.println(arr[i]+ "\t");
		}
		for(int i=0; i<n; i++)
			if(arr[i]> largest)
		{
		  secondLargest = largest;
		 largest=arr[i];
		}

		else if(arr[i] > secondLargest)
		{
			secondLargest = arr[i];
		}
	
		
		System.out.println("\nsecond largest number is:"+secondLargest);
		System.out.println("nlargest number is:"+largest);
		
		}

}


