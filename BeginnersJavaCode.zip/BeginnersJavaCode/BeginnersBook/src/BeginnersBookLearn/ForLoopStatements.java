package BeginnersBookLearn;

public class ForLoopStatements {
	
//	    public static void main(String args[]){
//	         for(int i=10; i>1; i--){
//	              System.out.println("The value of i is: "+i);
//	         }
//	    }
	
	//for design pattern
//	public static  void main(String args[]) {
//		
//		for(int i=1; i<=6; i++) {
//			for(int j=1; j<=i; j++) {
//				System.out.print("*");
//				
//			}
//			System.out.println();
//		}
//	
//
//	}
	
	//  Iterate an array using for loop
	
//	public static void main(String args[]) {
//		int arr[]= {2,4,45,9};
//		for (int i=0;i<arr.length;i++) {
//			System.out.println(arr[i]);
//		}
//	}
	
	//Let�s take the same example that we have seen above. We are rewriting it using enhanced for loop.
	 public static void main(String args[]){
	      int arr[]={2,11,45,9};
	      for (int num : arr) {
	         System.out.println(num);
	      }
	   }
	
	}
