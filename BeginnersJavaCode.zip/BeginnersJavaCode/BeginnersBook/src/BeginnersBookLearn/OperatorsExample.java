package BeginnersBookLearn;

//Operator is a symbol that instructs the compiler to perform a specific action. For example, a �+� operator 
//instructs the compiler to perform addition, a �>� operator instructs the compiler to perform 
//comparison, �=� for assignment and so on. In this guide, we will discuss operations in java with the help of 
//examples.
//
//Operator and Operand:
//In any operation, there is an operator and operands. For example: 
//In a+b, the �+� symbol is the operator and a & b are operands.

public class OperatorsExample {
	
	public static void main(String args[]) {
		
		//Basic arithmetic operators are: +, -, *, /, %
		//Note: Division (/) operator returns quotient while modulo operator(%) returns remainder. 
		//For example 10 % 5 would return 0 while 10/5 would return 2.
		
		int num1=100;
		int num2=20;
		
		System.out.println("num1+num2:"+(num1+num2));
		System.out.println("num1+num2:"+(num1-num2));
		System.out.println("num1+num2:"+(num1*num2));
		System.out.println("num1+num2:"+(num1/num2));
		System.out.println("num1+num2:"+(num1%num2));
	
		//Assignments operators in java are: =, +=, -=, *=, /=, %=
		
		int num3=10, num4;
		 num4=num3;
		 System.out.println("= Output:"+num4);
		 num4 +=num3;
		 System.out.println("+= Output:"+num4);
		 num4 -=num3;
		 System.out.println("-= Output:"+num4);
		 num4 *=num3;
		 System.out.println("*= Output:"+num4);
		 num4 /=num3;
		 System.out.println("/= Output:"+num4);
		 num4 %=num3;
		 System.out.println("%= Output:"+num4);
		 
//		 3) Unary Operators
//		 As the name suggests, The Unary operators in Java involve single operand. Java supports following unary operators:
//
//		 Unary minus(-)
//		 Increment(++)
//		 Decrement(- -)
//		 NOT(!)
//		 Bitwise Complement(~)
		
		 int num5=100;
		 int num6=200;
		 
		//minus(-) unary operator
		 int inverseNum= -num5;
		 System.out.println("opposite of num1: "+inverseNum);

		 //increment 
		 num5++;
		 System.out.println("Print increment number: "+num5);
		 
		 //decrement
		 num6--;
		 System.out.println("Print decrement number: "+num6);
		
// Logical Operators are used to evaluate the outcome of conditions. There are three logical operators: AND (&&),
// OR (||) and NOT (!). The AND and OR operators are used when multiple conditions are combined and we need to 
// evaluate the outcome as a whole.		 
		 
		 boolean b1=true;
		 boolean b2=false;
		 System.out.println("b1&&b2: "+(b1&&b2));
		 System.out.println("b1||b2: "+(b1||b2));
		 System.out.println("!(b1&&b2): "+!(b1&&b2));
		 
//Relational operator
		 
		 int num7=10;
		 int num8=20;
		 
		 if(num7 !=num8) {
			 System.out.println("Num7 is not equal Num8");
		 }
		 else {
			 System.out.println("Num7 and Num8 are equal");
		 }
		 if(num7 > num8) {
			 System.out.println("Num7 is greater than Num8 ");
		 }
		 else {
			 System.out.println("Num7 is not greater than num8");
		 }
		 if(num7 <num8) {
			 System.out.println("Num7 is less than Num8");
			 
		 }
		 else {
			 System.out.println("Num7 is not less than Num8");
		 }
		 
		 //6) Bitwise Operators
//Bitwise operators are used to perform bit-level operations. Let�s say you are performing an AND operation on two numbers (a & b), then these numbers are converted into binary numbers and then
//the AND operation is performed. Finally, the compiler returns decimal equivalent of the output binary number.
		
		 int num11 = 11;  /* 11 = 00001011 */
	     int num12 = 22;  /* 22 = 00010110 */
	     int result = 0;

	     result = num11 & num12;   
	     System.out.println("num1 & num2: "+result);

	     result = num11 | num12;   
	     System.out.println("num1 | num2: "+result);
	    
	     result = num11 ^ num12;   
	     System.out.println("num1 ^ num2: "+result);
	    
	     result = ~num11;   
	     System.out.println("~num1: "+result);
	    
	     result = num11 << 2;   
	     System.out.println("num1 << 2: "+result); result = num11 >> 2;   
	     System.out.println("num1 >> 2: "+result);
	     
	   //  7) Ternary Operator
//Ternary operator is the only operator in java that takes three operands. This operator is frequently
//used as a one line replacement for if�else statement.
//Syntax:=>
//variable = Condition ? Expression1: Expression2	 
	     
	     int num13, num14;
	     num13=25;
	     
	     num14=(num13==10)? 100:200;
	     System.out.println("num14: "+num14);
	     
	     num14=(num13==25)? 100: 200;
	     System.out.println("num14: "+num14);
	     
//Shift operators are used to perform bit manipulation. In this guide, 
//we will discuss various shift operators supported in java with the help of examples. 
//Java supports following shift operators:	  
	     
	     int num15=24;
	     //Left shift
	     System.out.println("num15<<2: "+(num15<<2));
	     
	     //Right shift
	     System.out.println("num15>>2: "+(num15>>2));
	}

}
