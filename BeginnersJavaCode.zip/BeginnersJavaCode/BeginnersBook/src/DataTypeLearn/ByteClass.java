//This can hold whole number between -128 and 127. Mostly used to save memory and when you are 
//certain that the numbers would be in the limit specified by byte data type.
//Default size of this data type: 1 byte.
//Default value: 0

package DataTypeLearn;

public class ByteClass {
	
	public static void main(String args[]) {
		
		byte nume;
		
		nume=15;
		System.out.println(nume);
	
		//SHORT=
		//This is greater than byte in terms of size and less than integer. Its range is -32,768 to 32767.
		//Default size of this data type: 2 byte
        short num;
		num=12344;
		System.out.println(num);
		
		//Long
		//Used when int is not large enough to hold the value, it has wider range than int data type, 
//		ranging from -9,223,372,036,854,775,808 to 9,223,372,036,854,775,807.
//		size: 8 bytes
//		Default value: 0
		
		long number;
		number=-1223465756547675L;
		System.out.println(number);
		
		
//		double
//		Sufficient for holding 15 decimal digits
//		size: 8 bytes
		
		double dub=125363585367436.78d;
		System.out.println(dub);
		
//		float
//		Sufficient for holding 6 to 7 decimal digits
//		size: 4 bytes
		
		float fot=53754762577f;
		System.out.println(fot);
		
//		boolean
//		It holds either true of false.
		
		boolean b=false;
		System.out.println(b);
		
//		char
//		It holds characters.
//		size: 2 bytes
		
		char ch='Z';
		System.out.println(ch);
				
	}
	
	
}

//Literals in Java
//A literal is a fixed value that we assign to a variable in a Program.
//
//int num=10;
//Here value 10 is a Integer literal.
//
//char ch = 'A';
//Here A is a char literal
//
//Integer Literal
//Integer literals are assigned to the variables of data type byte, short, int and long.
//
//byte b = 100;
//short s = 200;
//int num = 13313131;
//long l = 928389283L;
//Float Literals
//Used for data type float and double.
//
//double num1 = 22.4;
//float num2 = 22.4f;
//Note: Always suffix float value with the �f� else compiler will consider it as double.
//
//Char and String Literal
//Used for char and String type.
//
//char ch = 'Z';
//String str = "BeginnersBook";
