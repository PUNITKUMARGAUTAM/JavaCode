package Oops520223;

public class ClassExample {
	
	String webSite ;
	int webAge;
	
	
	ClassExample(String name, int age){
		this.webSite=name;
		this.webAge=age;
	}
	
   public static void main(String args[]) {
	   
	   ClassExample obj1= new ClassExample("ArvindKumar", 25);
	   ClassExample obj2= new ClassExample("Rupesh Srivastav",30);
	   
	   System.out.println(obj1.webSite + obj1.webAge);
	   System.out.println(obj2.webSite + obj2.webAge);
	   
   }

}
