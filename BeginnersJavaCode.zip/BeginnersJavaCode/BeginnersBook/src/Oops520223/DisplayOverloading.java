package Oops520223;

class OverLoadingExample {
	
	public void disp(char c) {
		System.out.println(c);
		
	}
	
	public void disp(char c ,int num) {
		System.out.println(c +" " +num);
		
	}
}

public class DisplayOverloading extends OverLoadingExample{
	
	public static void main(String ags[]) {
	
	DisplayOverloading obj= new DisplayOverloading();
	obj.disp('a');
	obj.disp('a',5);

}
}