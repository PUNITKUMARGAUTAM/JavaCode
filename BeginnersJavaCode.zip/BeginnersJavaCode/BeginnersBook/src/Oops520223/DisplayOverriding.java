package Oops520223;

 class Animals {
	 
	 void animalSound() {
		 System.out.println("Default method");
	 }
	
}

public class DisplayOverriding extends Animal {
	
	public void animalSound() {
		System.out.println("Woof");
	}
	
	public static void main(String args[]) {
	Animal obj = new DisplayOverriding();
   obj.animalSound();
	

}
}
