package Oops520223;


abstract class Animal {
	
	public abstract void animalSound();
}
public class DogClass  extends Animal{

	@Override
	public void animalSound() {
		
		System.out.println("Woof");
	}
	
	public static void main(String args[]) {
		
		Animal obj= new DogClass();
		obj.animalSound();
		
	}
	
	

}
