package Oops520223;

class Employee {
	
	private int count=0;

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
}


public class EncapsulationExample {
	
	public static void main(String args[]) {
		
		Employee obj= new  Employee();
		obj.setCount(3456789);
		System.out.println("print number of employee "+obj.getCount());
	}

}
