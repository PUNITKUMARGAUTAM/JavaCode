package Oops520223;


class Teacher {
	String Desigination="Teacher";
	String College="BeginingBook";
	
	void wtt() {
		System.out.println("Teaching");
	}
}

public class InheritanceExample  extends Teacher{
	
	String mainSubject="Maths";
	public static void main(String args[]) {
		 InheritanceExample obj= new InheritanceExample();
		 System.out.println(obj.College);
		 System.out.println(obj.Desigination);
		 System.out.println(obj.mainSubject);
		 obj.wtt();
		 
		
	}
	

}
