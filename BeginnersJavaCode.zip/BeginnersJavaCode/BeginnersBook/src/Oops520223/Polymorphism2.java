package Oops520223;

public class Polymorphism2 extends PolymorphismExample{

    @Override
    public void animalSound(){
        System.out.println("Roar");
    }
}
		 
	 
		 
		

