//package Oops520223;
//
//public class Polymorphism3 extends PolymorphismExample{
//	
//
//
//
//	@Override
//	public void animalSound() {
//		public static void main(String args[]) {
//			
//		
//			System.out.println("Woof");
//		}
//	
//		
//	
//	}
//
//
