package Oops520223;

	 
public  abstract class PolymorphismExample {
	public abstract void animalSound();

public static void main(String args[]) {
	
	System.out.println("punit");
	
	
}
 

}
