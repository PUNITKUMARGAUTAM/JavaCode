package TryCatchFunctionaity;

public class TryCatchFirst {

	
}
