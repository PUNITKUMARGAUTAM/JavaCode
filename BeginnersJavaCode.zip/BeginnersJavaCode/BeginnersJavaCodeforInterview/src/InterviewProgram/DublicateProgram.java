package InterviewProgram;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class DublicateProgram {
	
	public static void main(String args[]) {
		
//		ArrayList<String> list= new ArrayList<String>();
//		list.add("ABCD");
//		list.add("nhkjis");
//		list.add("ABCD");
//		list.add("zxy");
//		Set<String> s=new HashSet<String>();
//		
//		for(String name : list) {
//			if(s.add(name)==false)
//				System.out.println(name + " is dublicated");
//		}
//		
//	}
		//Reverse string
		
		String str="Automation";
		StringBuilder str2= new StringBuilder();
		str2.append(str);
		str2=str2.reverse();
		System.out.println(str2);
	}

}
