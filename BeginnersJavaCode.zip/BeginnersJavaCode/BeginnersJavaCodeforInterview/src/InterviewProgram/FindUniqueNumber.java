package InterviewProgram;

import java.util.Arrays;
import java.util.Scanner;

//Find unique numbers from given array without collection

//int[] arry = {34,76,23,88, 43,56,34, 23};
public class FindUniqueNumber {
	
	public static void main(String args[]) {
		
	int[] arr = {34,76,23,88, 43,56,34, 23};
	
	int n=8;
	for(int i=0; i<n; i++) {
		int cnt =0;
		for(int j=0; j<n; j++) {
			if(arr[j]==arr[i])
				cnt++;
		}
		if(cnt==1)
			System.out.println(arr[i]);
	}
	
	
	}
	}
		
		
		
		
	
	


