package InterviewProgram;

import java.util.Scanner;

//Print series 3,6,12,24,48,96 upto value is less than 1000

public class InterviewQuestion {
	
	public static void main(String args[]) {
		
		int s=3,n,j=1, i, term=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number of Term");
		n=sc.nextInt();
		for(i=1;i<=n; i++)
		{
			
			term=s*j;
			j=j+j;
			
			System.out.println(term+ " ");
			
		}
	}

}
