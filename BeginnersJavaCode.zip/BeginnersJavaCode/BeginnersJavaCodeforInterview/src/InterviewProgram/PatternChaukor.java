//package InterviewProgram;
//
//import java.util.Scanner;
//
//public class PatternChaukor {
//	
//	Scanner sc= new Scanner(System.in);
//    System.out.println("hgfdtgfhjjh");
//	 int num=sc.nextInt();
//	 for(int i=1; i<=num; i++) {
//		 for(int i=1; i<=num; i++) {
//			 if(i==1 || i==num || i==1 || i==num) {
//				 System.out.print("*");
//			 }
//			 else {
//				 
//				 System.out.print(" ");
//		 }
//		 
//		 System.out.println();
//	 }
//	
//	
//
//}
//}
//}
