package InterviewProgram;

import java.util.Scanner;

public class SwapTwoNumberUsingThirdVariable {
	
	public static void main(String args[]) {
		
		int x,y, temp;
		System.out.println("Enter x and y");
		Scanner in=new Scanner(System.in);
		x=in.nextInt();
		y=in.nextInt();
		
		//using third variable
//		System.out.println("Before Swapping" + x+y);
//		temp=x;
//		x=y;
//		y=x;
//		System.out.println("After Swapping" + x+y);
		
		//Using only two variable
		System.out.println("Before Swapping  using third variables\nx = "+ x+ "\ny=" + y);
		x=x+y;
		y=x-y;
		x=x-y;
		
		System.out.println("After Swapping without third variables\nx = "+ x+ "\ny=" + y);
		
		
	}

}
