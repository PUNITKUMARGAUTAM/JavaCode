package IntialInterviewProgram;

import java.util.Scanner;

//public class Fact {
//	
//	public static void main(String args[])
//	{
//		int n,fact=1;
//		System.out.println("Enter any number");
//		Scanner sc=new Scanner(System.in);
//		n=sc.nextInt();
//		for(int i=1; i<=n; i++)
//		{
//			fact=fact*i;
//		}
//		System.out.println("Factorial" + fact);
//	}
//
//}

class Fact{  
	 void fact(int  n){  
	  int fact=1;  
	  for(int i=1;i<=n;i++){  
	   fact=fact*i;  
	  }  
	 System.out.println("factorial is "+fact);  
	}  
	public static void main(String args[]){  
	 new Fact().fact(5);//calling method with anonymous object  
	}  
	}  
