package IntialInterviewProgram;

public class ReverseString {
	
	
		public static void main (String args[]){

		String str="EAT SLEEP CODE REPEAT";
		String rev = reverse(str);
		System.out.println("Reverse sentence:===" + rev);
		}
		
		public static String reverse(String s) {
			int x=s.indexOf(" ");
			
			if(x ==-1) 
				return s;
				
				return reverse(s.substring(x+1))+ " "+ s.substring(0,x);
			}
	

		}
		



