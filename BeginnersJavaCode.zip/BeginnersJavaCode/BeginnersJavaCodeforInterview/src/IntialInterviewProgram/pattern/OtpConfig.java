package IntialInterviewProgram.pattern;

import java.util.Random;

public class OtpConfig {
	
	static char[] OTP(int len)
	{
		System.out.print("Your OTP is: ");
		String numbers="0123456789";
		Random rndm_method= new Random();
		char[] otp=new char[len];
		for(int i=0; i<len;i++) {
			otp[i]=numbers.charAt(rndm_method.nextInt(len));
		}
		return otp;
		
	}
	public static void main(String args[]) {
		int length=5;
		System.out.println(OTP(length));
	}
}
