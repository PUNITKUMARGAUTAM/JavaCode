package IntialInterviewProgram.pattern;

import java.util.Scanner;

public class PatternMethod {

	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		
		int n=0;
		
		System.out.println("Enter a number of rows:: ");
		
		n=sc.nextInt();
		
		for(int i=1; i<=n; i++) {
			
			for(int j=1; j<=n-i; j++)
				System.out.println(" ");
			
			for(int k=1; k<=i; k++)
				System.out.println("*");
				
			// new line
			System.out.println();
			}
			
		}
	}

