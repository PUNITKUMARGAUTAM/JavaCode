package IntialInterviewProgram;

public class sample {

	public static void main(String[] args) {
		String s ="this is a line";
		String[] t=s.split(" ");
		System.out.println(t.length);

	}

}
