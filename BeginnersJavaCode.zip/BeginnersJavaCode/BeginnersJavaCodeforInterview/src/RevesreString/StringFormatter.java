package RevesreString;

public class StringFormatter {
	public static String reverseString(String str)
	{
		StringBuilder sb=new StringBuilder(str);
		sb.reverse();
		return sb.toString();
		}

}
