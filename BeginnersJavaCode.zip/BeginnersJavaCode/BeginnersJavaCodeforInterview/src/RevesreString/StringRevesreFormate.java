package RevesreString;

public class StringRevesreFormate {
	
	public static void  main(String args[])
	{
		System.out.println(StringFormatter.reverseString("My name is WTTians"));
		System.out.println(StringFormatter.reverseString("I am from varanasi"));
	}

}
