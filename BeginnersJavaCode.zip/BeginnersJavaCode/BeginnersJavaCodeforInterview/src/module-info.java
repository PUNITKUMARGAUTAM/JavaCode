module BeginnersJavaCodeforInterview {
}