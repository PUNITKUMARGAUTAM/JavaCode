package CollectionList;

import java.util.ArrayList;
import java.util.HashSet;

public class ArrayListDuplicate {
	
	public static void main(String[] args) {
		
		ArrayList<Integer> list= new ArrayList<>();
		
		list.add(12);
		list.add(15);
		list.add(11);
		list.add(12);
		
		System.out.println(list);
		
		HashSet<Integer> hs= new HashSet<>(list);
		
		list.clear();
		System.out.println(list);
		
		hs.addAll(list);
		System.out.println("Without duplicates values" + hs);
	}

}
