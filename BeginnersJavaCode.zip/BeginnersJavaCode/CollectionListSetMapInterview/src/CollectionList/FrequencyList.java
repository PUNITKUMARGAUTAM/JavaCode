package CollectionList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FrequencyList {
	
	public static void main(String[] args) {
		
		ArrayList<Integer> ls= new ArrayList<>();
		
		ls.add(12);
		ls.add(13);
		ls.add(12);
		ls.add(13);
		ls.add(10);
		
		System.out.println(ls);
		
	
		
		 Map<Integer, Integer> frequencyMap   = new HashMap<>();
	        
	        for (int num : ls) {
	        	frequencyMap .put(num, ((Map<Integer,Integer>) frequencyMap) .getOrDefault(num, 0) + 1);
	        }
	        
	        System.out.println("Frequency of elements: " + frequencyMap );
	}

}
