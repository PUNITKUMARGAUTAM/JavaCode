package CollectionList;

public class FrequenncyCount {
	
	public static void main(String[] args) {
		
		String str = "I was walking down a big blue street when I saw a blue bird flying in the blue sky";
		
		int count=0;
		
	}

}
