package CollectionList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class List2 {
	
	public static void main(String[] args) {
		
		List<Integer> it= new ArrayList<>();
		
		it.add(2);
		it.add(4);
		it.add(6);
		it.add(8);
		it.add(10);
		
		System.out.println(it);
		
		
		List<Integer> it1= new ArrayList<>();
		
		it1.add(5);
		it1.add(8);
		it1.add(12);
		it1.add(15);
		
		System.out.println(it1);
		
		
		HashSet<Integer> itr= new HashSet<>();
		it.retainAll(it1);
		System.out.println(it);
		
		
		
//		List<Integer> it2= new ArrayList<>();
//		it2.addAll(it1);
//		System.out.println();
	}

}
