package CollectionList;

import java.util.ArrayList;
import java.util.Collections;

public class ReverseList {
	
	public static void main(String[] args) {
		
		ArrayList ls= new ArrayList<>();
		
		ls.add(1);
		ls.add(12);
		ls.add(20);
		ls.add(3);
		ls.add(4);
		
		Collections.reverse(ls);
		System.out.println("Reverse List " + ls);
	}

}
