package CollectionList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ReverseString {
	
	public static void main(String[] args) {
		
//		String inp= "Punit";
//		
//		byte[] strAsByteArray= inp.getBytes();
//		byte [] result= new byte[strAsByteArray.length];
//		
//		for(int i=0; i<strAsByteArray.length; i++) {
//			result[i]= strAsByteArray [strAsByteArray.length-i-1];
//			System.out.println(new String(result));
//		}
//		
	
	
//	List<String> ls= new ArrayList<>();
//	ls.add("punit");
//	
//	Collections.reverse(ls);
//	
//	for(String st: ls) {
//		System.out.println("Print recerse value="+ st);
//		
//	}
		
	

//		String s = "Punit";
//		
//		int lang=s.length();
//		
//		String rev = "";
//		
//		for (int i=lang-1; i>=0; i-- ){
//			
//			rev= rev + s.charAt(i);
//		}
//		
//		System.out.println(rev);
//	
		
		
	
	
	}

}
