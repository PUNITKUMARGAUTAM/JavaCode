package Linkedlist;

import java.util.LinkedList;

public class InsertionFirst {
	
	public static void main(String[] args) {
		
		LinkedList<Integer> num= new LinkedList<>();
		
		num.addFirst(12);
		num.addFirst(13);
		num.addFirst(20);
		
		for(Integer element : num) {
			System.out.println(element);
		}
		
	}

}
