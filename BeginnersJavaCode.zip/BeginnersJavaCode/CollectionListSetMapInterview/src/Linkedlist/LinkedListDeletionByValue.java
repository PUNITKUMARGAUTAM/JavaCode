package Linkedlist;

import java.util.LinkedList;

public class LinkedListDeletionByValue {
	
	public static void main(String[] args) {
		
//		LinkedList<Integer> nn= new LinkedList<>();
//		
//		nn.add(12);
//		nn.add(23);
//		nn.add(39);
//		nn.add(49);
//		
//		
//		nn.remove(Integer.valueOf(2));
//		System.out.println(nn);
//		
//		
//		for(Integer ll: nn) {
//			System.out.println(ll);
//		}
		
		
		 LinkedList<Integer> linkedList = new LinkedList<>();
	        
	        linkedList.add(1);
	        linkedList.add(2);
	        linkedList.add(3);
	        
	        linkedList.remove(Integer.valueOf(2));
	        
	        for (Integer element : linkedList) {
	            System.out.println(element);
	        }
		
	}

}
