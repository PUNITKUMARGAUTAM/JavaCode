package Linkedlist;

import java.util.LinkedList;

public class LinkedListSizeClear {
	
	public static void main(String[] args) {
		
		LinkedList ls= new LinkedList<>();
		
		ls.add("Rohit");
		ls.add("Rajat");
		ls.add("Bhim");
		
		int size=ls.size();
		System.out.println("size of linked list == " + size);
		
		ls.clear();
		
		size = ls.size();
		System.out.println("Print size of clear value == "+ size);
	}

}
