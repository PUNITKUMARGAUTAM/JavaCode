package Linkedlist;

import java.util.LinkedList;

public class Linkedlist1 {
	
	public static void main(String[] args) {
		
		LinkedList<String> ll= new LinkedList<>();
		
		ll.add("Manmohan");
		ll.add("Raju");
		ll.add("Ramjanam");
		
		for(String element: ll) {
			System.out.println(element);
		}
		
	}

}
