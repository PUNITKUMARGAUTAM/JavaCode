package Linkedlist;

import java.util.LinkedList;

public class SerchingElment {
	
	public static void main(String[] args) {
		
		LinkedList<String> st= new LinkedList<>();
		
		st.add("Santosh");
		st.add("BOB");
		st.add("Raja");
		
		boolean constant= st.contains("BOB");
		
		System.out.println(constant);
		
		if(constant) {
			System.out.println(" BOB is present");
		}
		else {
			System.out.println("BOB is not present");
		}
	}

}
