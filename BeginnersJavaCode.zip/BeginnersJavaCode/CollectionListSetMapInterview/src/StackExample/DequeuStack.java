package StackExample;

import java.util.Deque;
import java.util.LinkedList;

public class DequeuStack {
	
	public static void main(String[] args) {
	    Deque<Integer> stack = new LinkedList<Integer>();

	    stack.push(10);
	    stack.push(20);
	    stack.push(30);

	    System.out.println(stack.pop()); // Output: 30
	    System.out.println(stack.size()); // Output: 2
	  }

}
