package StackExample;

import java.util.ArrayList;

public class StackArrayList {

	
	private ArrayList<Integer> stackList;

	  public void Stack() {
	    stackList = new ArrayList<Integer>();
	  }

	  public void push(int value) {
	    stackList.add(value);
	  }

	  public int pop() {
	    if (stackList.isEmpty()) {
	      System.out.println("Stack is empty. Cannot pop element.");
	      return -1;
	    } else {
	      int lastIndex = stackList.size() - 1;
	      int value = stackList.get(lastIndex);
	      stackList.remove(lastIndex);
	      return value;
	    }
	  }

	  public boolean isEmpty() {
	    return stackList.isEmpty();
	  }

	  public int size() {
	    return stackList.size();
	  }
	

   public static void main(String[] args) {
	   
	   StackArrayList stack = new StackArrayList();
	   stack.push(10);
	   stack.push(20);
	   stack.push(30);
	   System.out.println(stack.pop()); // Output: 30
	   System.out.println(stack.size()); // Output: 2
   }
}