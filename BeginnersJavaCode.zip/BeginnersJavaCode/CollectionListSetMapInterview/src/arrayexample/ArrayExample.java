package arrayexample;

public class ArrayExample {
	
	public static void main(String[] args) {
		
		
		int arr[]= {12,34,56,7,9};
		
		int maxNumber= arr[0];
		int minNumber= arr[0];
		
		for( int i=0; i<arr.length; i++) {
			if(maxNumber < arr[i]) {
				maxNumber = arr[i];
				
			}
			
			else if(minNumber > arr[i]) {
				minNumber = arr[i];
			}
		}
		
		System.out.println("Print max number = "+ maxNumber);
		System.out.println("Print min number = "+ minNumber);
	}

}
