package arrayexample;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ArrayIntersection {
	
	public static int[] arrayIntersection(int[] arr1, int[] arr2) {
        // Create a HashSet to store unique elements from the first array
        Set<Integer> set = new HashSet<>();
        for (int num : arr1) {
            set.add(num);
        }

        // Create a List to store the intersection elements
        List<Integer> intersection = new ArrayList<>();
        for (int num : arr2) {
            if (set.contains(num)) {
                intersection.add(num);
                set.remove(num); // Remove the element to handle duplicates
            }
        }

        // Convert the List to an array
        int[] result = new int[intersection.size()];
        for (int i = 0; i < intersection.size(); i++) {
            result[i] = intersection.get(i);
        }

        return result;
    }

    public static void main(String[] args) {
        int[] arr1 = {1, 2, 2, 3, 4, 5};
        int[] arr2 = {2, 2, 3, 6, 7};

        int[] intersection = arrayIntersection(arr1, arr2);

        System.out.println("Intersection elements:");
        for (int num : intersection) {
            System.out.print(num + " ");
        }
    }

}
