package arrayexample;

public class AverageValue {
	
	public static double averageElement(int[] array) {
		
		int sum=0;
		for(int i=0; i<array.length; i++) {
			
			sum+= array[i];
			
			}
		return (double) sum/array.length;
	}
	
	public static void main(String[] args) {
		
		int[] avg= {2,2,3,5,6,7,8};
		
		double sumavg= averageElement(avg);
		System.out.println("Average of all elemnt = " +sumavg);
		
		
	}

}
