package arrayexample;

public class ElementFrequency {
	
	public static int findFrequency(int[] array, int element) {
        int frequency = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i] == element) {
                frequency++;
            }
        }
        return frequency;
    }

    public static void main(String[] args) {
        int[] numbers = {5, 10, 15, 10, 20, 25, 10};
        int element = 10;
        int frequency = findFrequency(numbers, element);
        System.out.println("Frequency of " + element + " in the array: " + frequency);
    }

}
