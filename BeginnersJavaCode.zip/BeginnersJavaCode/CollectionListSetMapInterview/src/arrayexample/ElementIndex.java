package arrayexample;

public class ElementIndex {

	public static int findIndex(int[] array, int element) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == element) {
                return i;
            }
        }
        return -1; // Element not found
    }

    public static void main(String[] args) {
        int[] numbers = {5, 10, 15, 20, 25};
        int element = 15;
        int index = findIndex(numbers, element);
        if (index != -1) {
            System.out.println("Index of " + element + " in the array: " + index);
        } else {
            System.out.println("Element not found in the array.");
        }
    }
}
