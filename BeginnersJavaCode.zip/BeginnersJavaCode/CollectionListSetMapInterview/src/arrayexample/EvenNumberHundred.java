package arrayexample;

import java.util.Arrays;

public class EvenNumberHundred {
	
	public static void main(String[] args) {
		
//		int num1=1;
//		for(int num1=0; num1<=100; num1++) {
//			
//			if(num1%2==0) {
//				
//				System.out.println("Even number = " +num1);
//			}
//			
//			else {
//				System.out.println("Odd number" + num1);
//			}
//		}
		
		int size= 10;
		int num = 1;
		int arr[] = new int[size] ;
		for(int i = 0;i<size; i++) {
			if(i==0 || i==1) {
				arr[i]=num;
			}else {
				arr[i]=arr[i-1] + arr[i-2];
			}
		}
		for(int i = 0;i<arr.length;i++) {
			System.out.println(" value is  = "+arr[i]);
		
	}

	}}
