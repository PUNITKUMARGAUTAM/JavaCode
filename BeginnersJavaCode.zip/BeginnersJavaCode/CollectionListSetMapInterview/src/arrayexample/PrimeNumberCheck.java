package arrayexample;

import java.util.Scanner;

public class PrimeNumberCheck {

	public static void main(String[] args) {
		
		 Scanner scanner = new Scanner(System.in);
	      int i =0;
	      int num =0;
	      //Empty String
	      String  primeNumbers = "";
	      System.out.println("Enter the value of n:");
	      int n = scanner.nextInt();
	      scanner.close();
	      for (i = 1; i <= n; i++)  	   
	      { 		 		  
	         int counter=0; 		  
	         for(num =i; num>=1; num--)
	         {
		    if(i%num==0)
		    {
			counter = counter + 1;
		    }
		 }
		 if (counter ==2)
		 {
		    //Appended the Prime number to the String
		    primeNumbers = primeNumbers + i + " ";
		 }	
	      }	
	      System.out.println("Prime numbers from 1 to n are :");
	      System.out.println(primeNumbers);
	   }
	}
		
//		System.out.println("Start coding for Check Prime numbers from 1-100 ");
//		
//		for (int no=1; no<=100; no++) {
//			
//			int temp=0;
//			for(int i=2; i<=i-1; i++) {
//				
//				if(no%i==0) {
//					
//					temp=temp+1;
//					
//				}
//				
//			}
//			
//			if(temp==) {
//				
//				System.out.println(no);
//			}
			
//			else {
//				System.out.println("Not is prime");
//			}
//			
//		}
		
		
//		for(int num=1; num<=50; num++) {
//			
//			int temp=0;
//			for(int i=2; i<=i-1; i++) {
//				if(num%i==0) {
//					temp=temp+1;
//				}
//				
//			}
//			
//			if(temp==0) {
//				
//				System.out.println(num);
//				
//				
//			}
//			else {
//				System.out.println("Num is not prime");
//			}
//		}

