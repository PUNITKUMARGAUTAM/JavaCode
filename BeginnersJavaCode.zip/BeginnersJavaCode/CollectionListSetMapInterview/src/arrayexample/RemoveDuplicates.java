package arrayexample;

import java.util.Arrays;

public class RemoveDuplicates {
	
	public static int[] removeDuplicates(int[] array) {
        int[] result = new int[array.length];
        int j = 0;
        for (int i = 0; i < array.length - 1; i++) {
            if (array[i] != array[i + 1]) {
                result[j++] = array[i];
            }
        }
        result[j++] = array[array.length - 1];
        return Arrays.copyOf(result, j);
    }

    public static void main(String[] args) {
        int[] numbers = {5, 10, 10, 15, 20, 20, 25};
        int[] uniqueArray = removeDuplicates(numbers);
        System.out.println("Array with duplicates removed: " + Arrays.toString(uniqueArray));

}

}