package arrayexample;

public class ReverseListExample {

	public static void main(String[] args) {
		
		String str= "Punit";
		
		int len=str.length();
		
		String str1= "";
		
		for(int i= len-1; i>=0; i--) {
			
			str1= str1+str.charAt(i);
		}
		System.out.println(str1);
		System.out.println(len);
		
	}
}
