package arrayexample;

public class SecondeLargest {
	
	
	public static int findLargest(int array[]) {
		
		int largest=array[0];
		int secondLargest= Integer.MIN_VALUE;
		for(int i=1; i<array.length; i++) {
			if(array[i] > largest) {
				secondLargest= largest;
				largest= array[i];
			}
			
			else if(array[i] > secondLargest && array[i] !=largest) {
				secondLargest=array[i];
			}
		}
		
		return secondLargest;
	}
	
	public static void main(String[] args) {
		
		int[] arry= {1,2,3,34,45,67,89};
		int secondElement= findLargest(arry);
		System.out.println(secondElement);
		
		
	}

}
