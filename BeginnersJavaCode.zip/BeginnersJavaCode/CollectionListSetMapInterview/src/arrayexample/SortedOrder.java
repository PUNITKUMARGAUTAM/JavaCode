package arrayexample;

public class SortedOrder {
	
	
	public static boolean isSorted (int[] array) {
		for(int i=0; i<array.length-1; i++ ) {
			if(array[i] > array[i+1]) {
				return false;
				
			}
			
		}
		
		return true;
		
	}
	
	public static void main(String[] args) {
		
		int[] arr = {5, 10, 15, 20, 25};
		
		boolean sorted= isSorted(arr);
		System.out.println(sorted);
		
		
	}

}
