package hashmap;

import java.util.HashMap;
import java.util.Map;

public class CountWord {
	
	public static void main(String[] args) {
        String sentence = "Java is a popular programming language, and Java is used in many applications.";
        String[] words = sentence.split(" ");
        
        Map<String, Integer> wordCountMap = new HashMap<>();
        
        for (String word : words) {
            if (wordCountMap.containsKey(word)) {
                int count = wordCountMap.get(word);
                wordCountMap.put(word, count + 1);
            } else {
                wordCountMap.put(word, 1);
            }
        }
        
        for (Map.Entry<String, Integer> entry : wordCountMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

}
