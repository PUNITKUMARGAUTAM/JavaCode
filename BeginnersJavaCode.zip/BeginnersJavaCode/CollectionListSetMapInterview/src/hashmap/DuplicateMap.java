package hashmap;

import java.util.HashMap;
import java.util.Map;

public class DuplicateMap {
	
	public static void main(String[] args) {
		
		Map<Integer,String> map= new HashMap<>();
		
		map.put(12, "Mohit");
		map.put(14, "Raju");
		map.put(16, "Janki");
		
		System.out.println("Iterating Hashmap");
		
		for(Map.Entry m :map.entrySet()) {
			
			System.out.println(m.getKey() + "" + m.getValue());
		}
		
		
	}

}
