package hashmap;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PhoneBook {
	
	public static void main(String[] args) {
        Map<String, String> phoneBook = new HashMap<>();
        phoneBook.put("John Doe", "1234567890");
        phoneBook.put("Jane Smith", "9876543210");
        phoneBook.put("Mike Johnson", "5678901234");
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a name: ");
        String name = scanner.nextLine();
        
        if (phoneBook.containsKey(name)) {
            String phoneNumber = phoneBook.get(name);
            System.out.println("Phone number: " + phoneNumber);
        } else {
            System.out.println("Contact not found.");
        }
    }

}
