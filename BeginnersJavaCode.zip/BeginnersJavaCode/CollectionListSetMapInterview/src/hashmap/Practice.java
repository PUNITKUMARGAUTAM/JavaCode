package hashmap;

import java.util.Map;
import java.util.TreeMap;

public class Practice {
	
	public static void main(String[] args) {
		
		TreeMap<Integer, String > tree= new  TreeMap<>();
		
		tree.put(12, "Mehar");
		tree.put(11, "Raju");
		tree.put(9, "Sumit");
		tree.put(13, "Rajat");
		
		System.out.println("HeadMap" + tree.headMap(11));
		
		System.out.println("TailMap" + tree.tailMap(9));
		
		 System.out.println("subMap: "+tree.subMap(9, 13));   
		
		for(Map.Entry  m : tree.entrySet()) {
			System.out.println(m.getKey()+ "=" + m.getValue());
		}
	}

}
