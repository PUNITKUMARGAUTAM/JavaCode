package queue;

import java.util.LinkedList;

public class MergeQueues {
	
	public static Queue<Integer> mergeQueues(Queue<Integer> queue1, Queue<Integer> queue2) {
        Queue<Integer> mergedQueue = new LinkedList<>();

        while (!queue1.isEmpty() || !queue2.isEmpty()) {
            if (!queue1.isEmpty()) {
                mergedQueue.offer(queue1.poll());
            }
            if (!queue2.isEmpty()) {
                mergedQueue.offer(queue2.poll());
            }
        }

        return mergedQueue;
    }

    public static void main(String[] args) {
        Queue<Integer> queue1 = new LinkedList<>();
        queue1.offer(1);
        queue1.offer(3);
        queue1.offer(5);

        Queue<Integer> queue2 = new LinkedList<>();
        queue2.offer(2);
        queue2.offer(4);
        queue2.offer(6);

        System.out.println("Queue 1: " + queue1);
        System.out.println("Queue 2: " + queue2);

        Queue<Integer> mergedQueue = mergeQueues(queue1, queue2);
        System.out.println("Merged Queue: " + mergedQueue);
    }

}
