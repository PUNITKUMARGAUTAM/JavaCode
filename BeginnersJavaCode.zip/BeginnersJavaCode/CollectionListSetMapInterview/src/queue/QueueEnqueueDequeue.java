package queue;

public class QueueEnqueueDequeue {
	
	 private int[] arr;
	    private int front;
	    private int rear;
	    private int maxSize;

	    public void Queue(int size) {
	        maxSize = size;
	        arr = new int[maxSize];
	        front = -1;
	        rear = -1;
	    }

	    public boolean isEmpty() {
	        return front == -1;
	    }

	    public boolean isFull() {
	        return rear == maxSize - 1;
	    }

	    public void enqueue(int data) {
	        if (isFull()) {
	            System.out.println("Queue is full");
	        } else {
	            if (front == -1)
	                front = 0;
	            rear++;
	            arr[rear] = data;
	        }
	    }

	    public void dequeue() {
	        if (isEmpty()) {
	            System.out.println("Queue is empty");
	        } else {
	            System.out.println("Dequeued element: " + arr[front]);
	            if (front == rear) {
	                front = -1;
	                rear = -1;
	            } else {
	                front++;
	            }
	        }
	    }

	    public void display() {
	        if (isEmpty()) {
	            System.out.println("Queue is empty");
	        } else {
	            System.out.print("Queue: ");
	            for (int i = front; i <= rear; i++) {
	                System.out.print(arr[i] + " ");
	            }
	            System.out.println();
	        }
	    }

	    public static void main(String[] args) {
	        Queue queue = new Queue(5);
	        queue.enqueue(1);
	        queue.enqueue(2);
	        queue.enqueue(3);
	        queue.display(); // Output: Queue: 1 2 3
	        queue.dequeue();
	        queue.display(); // Output: Queue: 2 3
	    }

}
