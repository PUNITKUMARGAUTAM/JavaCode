package queue;

import java.util.LinkedList;

public class QueueSum {
	
	public static int getSum(Queue<Integer> queue) {
        int sum = 0;
        Queue<Integer> tempQueue = new LinkedList<>(queue);

        while (!tempQueue.isEmpty()) {
            sum += tempQueue.poll();
        }

        return sum;
    }

    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();
        queue.offer(1);
        queue.offer(2);
        queue.offer(3);
        System.out.println("Original Queue: " + queue);
        int sum = getSum(queue);
        System.out.println("Sum of Queue Elements: " + sum);
        System.out.println("Queue after sum calculation: " + queue);
    }

}
