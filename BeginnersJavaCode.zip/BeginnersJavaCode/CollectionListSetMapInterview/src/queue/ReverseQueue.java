package queue;

import java.util.LinkedList;

public class ReverseQueue {
	
	 public static void reverse(Queue<Integer> queue) {
	        if (queue.isEmpty()) {
	            return;
	        }
	        int data = queue.poll();
	        reverse(queue);
	        queue.offer(data);
	    }

	    public static void main(String[] args) {
	        Queue<Integer> queue = new LinkedList<>();
	        queue.offer(1);
	        queue.offer(2);
	        queue.offer(3);
	        System.out.println("Original Queue: " + queue);
	        reverse(queue);
	        System.out.println("Reversed Queue: " + queue);
	    }

}
