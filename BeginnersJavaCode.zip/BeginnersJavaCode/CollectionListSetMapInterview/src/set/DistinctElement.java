package set;

import java.util.HashSet;

public class DistinctElement {
	
	public static void main(String[] args) {
		
	
	
	
	int[] arr= {1,2,3,4,2,1,5,6,8};
	
	HashSet<Integer> hs1= new HashSet<>();
	
	for(int i=0; i<arr.length; i++) {
		
		hs1.add(arr[i]);
		
	}
	int distinct=hs1.size();
	System.out.println("Number of dictinct element = " + distinct);
}
}
	