package set;

import java.util.HashSet;

public class DuplicateElement {
	
	public static void main(String[] args) {
		
		int[] arr= {1,2,3,4,5,6,1,2,3,};
		
		HashSet<Integer> hs= new HashSet<>();
		
		for(int i=0; i<arr.length; i++) {
			
			if(!hs.add(arr[i])) {
				System.out.println("duplicates element found "+ arr[i]);
			}
		}
	}

}
