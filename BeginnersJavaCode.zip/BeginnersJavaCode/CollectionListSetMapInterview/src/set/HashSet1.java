package set;

import java.lang.reflect.Array;
import java.util.HashSet;

public class HashSet1 {
	
	public static void main(String[] args) {
		
		int[] array= {1,2,3,4,2,3,4,5,6,7,8};
		
		HashSet<Integer> set= new HashSet<>();
		
		for(int i=0; i< array.length; i++) {
			set.add(array[i]);
			
			
			
		}
		
		System.out.println("Print value of remove set" + set);
		
	}

}

