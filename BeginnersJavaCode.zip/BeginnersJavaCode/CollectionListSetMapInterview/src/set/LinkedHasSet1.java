package set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;



public class LinkedHasSet1 {
	
	public static void main(String[] args) {
		
		LinkedHashSet<String> hs= new LinkedHashSet<>();
		
		hs.add("Rohit");
		hs.add("Rina");
		hs.add("Suresh");
		hs.add("Aumit");
		
		Iterator<String> i= hs.iterator();
			
		while(i.hasNext()) {
			System.out.println(i.next());
		}
	}

}
