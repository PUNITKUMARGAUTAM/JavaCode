package set;

import java.util.HashSet;

public class RemoveElement {
	
	public static void main(String[] args) {
		
		HashSet<String> hs= new HashSet<>();
		
		hs.add("Sonu");
		hs.add("Suresh");
		hs.add("Rajat");
		hs.add("Suresh");
		
		System.out.println("Before remove any element" + hs);
		
		hs.remove("Sonu");
		System.out.println("After remove elments" + hs);
	}

}
