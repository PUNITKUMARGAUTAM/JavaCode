package set;

import java.util.HashSet;

public class UnionElement {
	
	public static void main(String[] args) {
		
		HashSet<Integer> set= new HashSet<>();
		
		set.add(12);
		set.add(23);
		set.add(67);
		
		System.out.println(set);
		
		HashSet<Integer> set1= new HashSet<>();
		
		set1.add(35);
		set1.add(56);
		set1.add(78);
		
		System.out.println(set1);
		
		HashSet<Integer> set3= new HashSet<>(set);
		set3.addAll(set1);
		
		System.out.println("Union element" + set3);
		
	}
	
	

}
