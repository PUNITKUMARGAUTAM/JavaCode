package logicBuild;

public class FibonacciSeries {
	
	public static void main(String[] args) {
		
		int size= 10;
		int num = 1;
		int arr[] = new int[size] ;
		for(int i = 0;i<size; i++) {
			if(i==0 || i==1) {
				arr[i]=num;
			}else {
				arr[i]=arr[i-1] + arr[i-2];
			}
		}
		for(int i = 0;i<arr.length;i++) {
			System.out.println(" value is  = "+arr[i]);
		
	}
	}

}
