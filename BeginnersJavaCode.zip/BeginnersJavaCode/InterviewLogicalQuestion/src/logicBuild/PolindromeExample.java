package logicBuild;

import java.util.Scanner;

public class PolindromeExample {
	
	public static void main(String[] args) {
		

	System.out.println(isPolindrom(122));
	
	}
	static boolean isPolindrom(int x) 
	
	{
		int temp=x;
		int rev=0;		
		
	
	
	while(x>0) 
	{
		
		int digit=x%10;
	    rev=(rev*10)+digit;
	    x=x/10;
		
	}	
	
	if(rev==temp) 
	{
		return true;
	}
	return false;
	
}
	
}
	
	
	
	
	
	
	
	
	
	
//	Scanner sc= new Scanner(System.in);
//	System.out.println("Enter a number");
//	int no=sc.nextInt();
//	
////	int no=121;
//	int temp=no;
//	
//	int rev=0, rem;
//	while(temp!=0) {
//		
//		rem=temp%10;
//		rev=rev*10+rem;
//		temp=temp/10;
//		
//	}
//	if(no==rev) 
//	{
//		System.out.println(no + " Is polindrome number");
//	}
//	else {
//		System.out.println(no + " is not prime number");
//	}
//}

	
	
//}