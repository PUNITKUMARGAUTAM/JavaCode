module InterviewLogicalQuestion {
}