package lambdaexpression;

@FunctionalInterface
interface MyFunctionalInterface {
    void doSomething();
}

public class FunctionalInterfaceExample {
    public static void main(String[] args) {
        // Using a lambda expression
        MyFunctionalInterface lambda = () -> {
            System.out.println("Lambda expression");
        };
        lambda.doSomething();

        // Using a method reference
        MyFunctionalInterface methodRef = FunctionalInterfaceExample::someMethod;
        methodRef.doSomething();
    }

    private static void someMethod() {
        System.out.println("Method reference");
    }
}
