package lambdaexpression;

import java.util.ArrayList;
import java.util.List;

interface DataFetcher {
    String fetchData(String url);
}

public class LambdaDataFetcher {
    public static void main(String[] args) {
        // Create a list of URLs
        List<String> urls = new ArrayList<>();
        urls.add("https://api.example.com/data1");
        urls.add("https://api.example.com/data2");
        urls.add("https://api.example.com/data3");

        // Fetch data using lambda expressions
        fetch(urls, url -> {
            // Simulate data fetching by printing the URL
            System.out.println("Fetching data from " + url);
            // Implement your actual data fetching logic here and return the fetched data
            return "Data from " + url;
        });
    }

    public static void fetch(List<String> urls, DataFetcher fetcher) {
        for (String url : urls) {
            String data = fetcher.fetchData(url);
            System.out.println("Fetched data: " + data);
        }
    }
}
