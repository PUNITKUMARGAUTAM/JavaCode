package lambdaexpression;

import java.util.ArrayList;
import java.util.List;

public class LambdaExpressionEx {
	

	public static void main(String[] args) {
		
	
	
	List<String> name=  new ArrayList<String>();

	name.add("Manmohan");
	name.add("raju");
	name.add("Zebra");
	name.add("Amit");
	
	name.sort((name1,name2 )-> name1.compareTo(name2));
	name.forEach(name3 -> System.out.println(name3));
	
	System.out.println("*********************");
	
	name.removeIf(name4 -> name4.startsWith("A"));
	name.forEach(System.out::println);
	
}
}


//public class FilterExample {
//    public static void main(String[] args) {
//        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
//
//        // Filter even numbers using lambda expression
//        List<Integer> evenNumbers = numbers.stream()
//                .filter(number -> number % 2 == 0)
//                .toList();
//
//        // Print the filtered even numbers
//        System.out.println("Even numbers: " + evenNumbers);
//    }
//}