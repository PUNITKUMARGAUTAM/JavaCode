package lambdaexpression;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamApiEx {
    public static void main(String[] args) {
//        List<String> fruits = new ArrayList<>();
//        fruits.add("Apple");
//        fruits.add("Banana");
//        fruits.add("Mango");
//        fruits.add("Orange");
//        fruits.add("Grapes");
//
//        // Example 1: Filtering elements using stream
//        List<String> filteredFruits = fruits.stream()
//                .filter(fruit -> fruit.startsWith("A"))
//                .collect(Collectors.toList());
//        System.out.println("Filtered fruits: " + filteredFruits);
//
//        // Example 2: Transforming elements using stream
//        List<String> upperCaseFruits = fruits.stream()
//                .map(String::toUpperCase)
//                .collect(Collectors.toList());
//        System.out.println("Uppercase fruits: " + upperCaseFruits);
//
//        // Example 3: Applying operations on elements using stream
//        String concatenatedFruits = fruits.stream()
//                .reduce("", (a, b) -> a + ", " + b);
//        System.out.println("Concatenated fruits: " + concatenatedFruits);
    	
//    	using map
    	
    
    	        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

    	        // Example 1: Doubling each number in the list
    	        List<Integer> doubledNumbers = numbers.stream()
    	                .map(number -> number * 2)
    	                .collect(Collectors.toList());
    	        System.out.println("Doubled numbers: " + doubledNumbers);

    	        // Example 2: Converting each number to a string
    	        List<String> numberStrings = numbers.stream()
    	                .map(Object::toString)
    	                .collect(Collectors.toList());
    	        System.out.println("Number strings: " + numberStrings);
    }
}