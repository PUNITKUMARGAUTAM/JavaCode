package ArrayExample;

import java.util.Scanner;

public class ArrayExampleFirst {
	 
//		public static void main(String args[]){  
//		int a[]=new int[5];//declaration and instantiation  
//		a[0]=10;//initialization  
//		a[1]=20;  
//		a[2]=70;  
//		a[3]=40;  
//		a[4]=50;  
//		//traversing array  
//		for(int i=0;i<a.length;i++)//length is the property of array  
//		System.out.println(a[i]);  
//		}}  


//public static void main(String args[]){  
//int a[]={33,3,4,5};//declaration, instantiation and initialization  
////printing array  
//for(int i=0;i<a.length;i++)//length is the property of array  
//System.out.println(a[i]);  
//}}  
	
//	public static void main(String[] args) {
//		
//		int a[]= new  int [10];
//		
//		Scanner sc = new Scanner(System.in);
//		
//		for(int i=0; i<=10;i++) {
//			System.out.println("Enter a number");
//			
//			a[i]=sc.nextInt();
//			
//		}
//		
//		for(int i=0; i<10; i++)
//			System.out.println(a[i]);
//	}
	
	//Java Program to print the array elements using for-each loop  
	
//	public static void main(String args[]){  
//		int arr[]={33,3,4,5};  
//		//printing array using for-each loop  
//		for(int i:arr)  
//		System.out.println(i);  
//		}}  

	//creating a method which receives an array as a parameter  
	static void min(int arr[]){  
	int min=arr[0];  
	for(int i=1;i<arr.length;i++)  
	 if(min>arr[i])  
	  min=arr[i];  
	  
	System.out.println(min);  
	}  
	  
	public static void main(String args[]){  
	int a[]={33,3,4,5};//declaring and initializing an array  
	min(a);//passing array to method  
	}}  


