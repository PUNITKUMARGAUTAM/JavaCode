package CollectionInfo;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;

public class CollectionExample2 {
	
	public static void main(String[] args) {
		
		ConcurrentLinkedQueue<Integer> queue = new ConcurrentLinkedQueue<Integer>();
		Set<Integer> set= new HashSet<Integer>();
		
		Collections.addAll(set, 11,21,23,45);
		System.out.println("Collection :");
		
		Iterator<Integer> itr= set.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		set.clear();
		
		Boolean b1 = set.isEmpty();
		if(b1) {
			System.out.println("Queue is empty");
			
		}
		
		else {
			System.out.println("Queue is not empty");
		}
		
		for(int i=1; i<=21; i++) {
			queue.add(i);
		}
			System.out.println("Element in the queue" + queue);
			
			for(int i=1; i<=11; i++) {
				int j= i*5;
				set.add(j);
			}
			
			queue.retainAll(set);
			System.out.println("Multiple of 5 "+ queue);
	}
	
	

}
