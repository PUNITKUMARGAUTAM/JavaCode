package CollectionInfo;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class CollectionExampleFirst {
	
	public static void main(String[] args) {
		
		Set<Integer> set= new HashSet<>();
		
		set.add(12);
		set.add(23);
		set.add(67);
		set.add(35);
		
		System.out.println("Print initial set value=" + set);
		
		Collections.addAll(set,1,3,4,7,8,9);
		
		System.out.println("Print final set value=" + set);
		
		int size=set.size();
		System.out.println("Print size" + size);
		
		Boolean val=set.contains(7);
		if(val) {
			System.out.println("7 is present in collection");
		}
		
		else {
			System.out.println("7 is not present in collection");
		}
		
		set.clear();
		System.out.println("Element in collection "+ set);
	

	}

}
