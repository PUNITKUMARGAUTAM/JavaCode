package ComparableInterfaceExample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ComparatorSort {

	public static void main(String[] args) {
		
		ArrayList<ComparatorStudent> al= new ArrayList<ComparatorStudent>();
		
		al.add(new ComparatorStudent(1,"Rahul",23));
		al.add(new ComparatorStudent(2,"Surseh",28));
		al.add(new ComparatorStudent(3,"Abhishek",18));
		al.add(new ComparatorStudent(4,"Zebra",25));
		
		Comparator<ComparatorStudent> cm1= Comparator.comparing(ComparatorStudent::getName);
		Collections.sort(al,cm1);
		
		System.out.println("Sorting by Name");
		
		for(ComparatorStudent st: al) {
			System.out.println("rollno = " + st.rollno +   ",Name= " + st.name +   " , Age= " + st.age );
		}
		
		//Sorting element on basis of age
		Comparator<ComparatorStudent> cm2= Comparator.comparing(ComparatorStudent :: getAge);
		Collections.sort(al,cm2);
		System.out.println("Sorting by age");
		
		for(ComparatorStudent st1:al) {
			System.out.println("rollno = " + st1.rollno +   ",Name= " + st1.name +   ", Age= " + st1.age );
		}
	}
	
}
