package ExceptionHandling;

public class MultipleCatchException {
	
	public static void main(String[] args) {
		
		try {
			
			String s=null;
			System.out.println(s.length());
		}
		
		catch(ArithmeticException ae){
			System.out.println("Arithmatic exception=========");
			
		}
		
		catch(ArrayIndexOutOfBoundsException ai) {
			System.out.println("Array index out of bound exception");
		}
		
		catch(Exception e) {
		System.out.println("Parent exception ");
	}
		
		System.out.println("Print rest of the code");
	}

}
