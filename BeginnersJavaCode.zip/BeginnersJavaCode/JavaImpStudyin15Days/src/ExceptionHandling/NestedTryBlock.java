package ExceptionHandling;

public class NestedTryBlock {
	
	public static void main(String[] args) {
		
		try {
			
			try {
				System.out.println("Going to divide by zero.........");
				
				int a=39/0;
			}
			
			catch(Exception e) {
				System.out.println(e);
			}
			
			try {
				
				int a[]= new int[5];
				
				a[5]=4;
			}
			catch(ArrayIndexOutOfBoundsException ae){
				System.out.println(ae);
				
			}
			
			System.out.println("Other statments");
		}
		
		catch(Exception e) {
			System.out.println("Handle the exception ");
		}
		
	}

}
