package ExceptionHandling;

public class ThrowThrowsExample {
	
	static void method() throws ArithmeticException{
		
		System.out.println("Inside the method");
		
		throw new ArithmeticException("throwing ArithmeticException");  
	}
	
	public static void main(String[] args) {
		
		try {
			
			method();
		}
		
		catch(ArithmeticException ae){
			   System.out.println("caught in main() method");  
			
		}
	}
	
 

}
