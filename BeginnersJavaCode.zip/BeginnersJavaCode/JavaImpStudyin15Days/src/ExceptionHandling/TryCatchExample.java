package ExceptionHandling;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class TryCatchExample {
	
	public static void main(String[] args) {
//		try {
//			
//			int a=50/0;
//
//		}
//		catch(ArithmeticException e) {
//			System.out.println(e);
//		}
//		
//		System.out.println("Rest of the code");
		
		
//		try {
//			
//			int a= 50/0;
//		}
//		
//		catch (Exception e) {
//			System.out.println("Cant divide by zero");
//		}
//			
		
		PrintWriter pw;
		
		try {
			pw = new PrintWriter("jp.txt");
			pw.println("saved");
		}
		catch (FileNotFoundException e){
			
			System.out.println(e);
			
		}
		
		System.out.println("File uploaded successfully");
		
		
		
	}

}
