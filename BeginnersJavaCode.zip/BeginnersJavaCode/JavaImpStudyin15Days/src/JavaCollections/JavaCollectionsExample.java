package JavaCollections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

//Java collection class is used exclusively with static methods that operate on or return collections. It inherits Object class.
//The important points about Java Collections class are:
//Java Collection class supports the polymorphic algorithms that operate on collections.
//Java Collection class throws a NullPointerException if the collections or class objects provided to them are null.

//declaration
//public class Collections extends Object  



public class JavaCollectionsExample {
	
	public static void main(String[] args) {
		
		List<String> str= new ArrayList<String>();
		
		str.add("Rahul");
		str.add("Shiva");
		str.add("Rohit");
		
		System.out.println("Intial value of element" + str);
		Collections.addAll(str, "Java","C++");
		System.out.println("After adding element"+str);
		
		String[] strArry= {"CSE","ME"};
		Collections.addAll(str, strArry);
		System.out.println("After adding collection value"+ str);
		
	}

}
