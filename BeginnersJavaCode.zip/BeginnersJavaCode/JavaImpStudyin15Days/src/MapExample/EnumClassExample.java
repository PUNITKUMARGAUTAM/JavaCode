package MapExample;

import java.util.EnumSet;
import java.util.Iterator;
import java.util.Set;

//Java EnumSet class is the specialized Set implementation for use with enum types. 
//It inherits AbstractSet class and implements the Set interface.

//Enum declaration
//public abstract class EnumSet<E extends Enum<E>> extends AbstractSet<E> implements Cloneable, Serializable  
enum days {  
	  SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY  
	}  
	public class EnumClassExample {  
	  public static void main(String[] args) {  
	    Set<days> set = EnumSet.of(days.TUESDAY, days.WEDNESDAY);  
	    // Traversing elements  
	    Iterator<days> iter = set.iterator();  
	    while (iter.hasNext())  
	      System.out.println(iter.next());  
	  }  
	}  
	
	
	//  EnumSet Example: allOf() and noneOf()
	
//	enum days {  
//		  SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY  
//		}  
//		public class EnumSetExample {  
//		  public static void main(String[] args) {  
//		    Set<days> set1 = EnumSet.allOf(days.class);  
//		      System.out.println("Week Days:"+set1);  
//		      Set<days> set2 = EnumSet.noneOf(days.class);  
//		      System.out.println("Week Days:"+set2);     
//		  }  
//		}  
