//package MapExample;
//
//@Entity
//@Table
//public class Jpa {
//	
//	@Id
//	
//	
//	private int id;
//	@Column(name="Names_upper")
//	private String name;
//	private int age;
//	private String address;
//	
//	
//	
//
//	
//	
//
//
//
//}
//
//
//@Repository
//
//public interface Rishabh extends JpaRepository <String>{
//	
//	NativeQuery()
//}
//
//
//
//
