package MapExample;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

public class Linkesd {
	
	public static void main(String args[]) {
		
		LinkedList<String> str= new LinkedList<String>();
		str.add("Rahul");
		str.add("Aohit");
		Collections.sort(str);
		System.out.println(str);
//		Iterator iterator= str.iterator();
	}

}

//public CustomerEntity findByFirstNameIgnoreCase(String firstName);
//
//public CustomerEntity findByOfCustomerId(Long custId);

//@Query (value = "select * from QC_master.Qm_user@DBLINK_UAT_MFIN where LOGINNAME = ?1 and IS_ACTIVE = 'A'", nativeQuery = true)
//UserMasterEntity findByLoginName(String loginName);
