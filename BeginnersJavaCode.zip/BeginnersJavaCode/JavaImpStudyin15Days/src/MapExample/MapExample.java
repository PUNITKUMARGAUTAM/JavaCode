package MapExample;

import java.util.HashMap;
import java.util.Map;

public class MapExample {
	
	public static void main(String[] args) {
		
		Map<Integer,String> map= new HashMap<Integer,String>();
		
		map.put(1, "Rahu");
		map.put(2, "RahuKumar");
		map.put(3, "RahuSingh");
		map.put(4, "RahuPatel");
		
		for(Map.Entry  m:map.entrySet() ) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}

}
