package OopsPrincipleOfJava;

abstract class Animals {
	abstract  void walk(); 
		public void eats() {
			System.out.println("Animal Eats");
		}
		
		Animals() {
			System.out.println("Creating constructor");
		}
	
}
	
	class Horse extends Animals{
		
		Horse(){
			System.out.println("Create horse");
		}
		public void walk() {
			System.out.println("Walks on 4 legs");
		}
		
		
	}
	
	class Chicken extends Animals{
		public void walk() {
			System.out.println("Walks on 2 legs ");
		}
	}


public class AbstractExample {
	
	public static void main(String[] args) {
		
		Horse hs = new Horse();
//		 hs.walk();
//		 hs.eats();
//		 
//		Chicken ch= new Chicken();
//		ch.walk();
		
//		Animals an=  new Animals();  // we can't create object of abstract class
//		an.walk();
	
//		Chicken ch= new Chicken();
	}      
	
}

