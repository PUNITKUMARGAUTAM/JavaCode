package OopsPrincipleOfJava;


class University{
	
	 String name= "GLA University";
	
}

public class AccessModifiers {
	
	public static void main(String[] args) {
		
		University un=new University();
		System.out.println("Name of University= " + un.name);
		
	}

}
