package OopsPrincipleOfJava;

import java.util.Scanner;

class A {
	
	int a,b;
	 void input() {
		 
		 Scanner sc= new Scanner(System.in);
		 System.out.println("Enter the number A ");
		  a= sc.nextInt();
		  
		  System.out.println("Enter the number B");
		  b=sc.nextInt();
	 }
}

class B extends A{
	void add() {
		System.out.println("Add"+ (a+b));
	}
}

class C extends A{
	void sub() {
	System.out.println("Sub"+ (a-b));
}
}

public class HierarchicalInheritance {
	
	public static void main(String[] args) {
		
		B b= new B();
		b.input();
		b.add();
		
		C c= new C();
		c.input();
		c.sub();
	}

}



//class Animal{
//public void animal() {
//	System.out.println("not speaking");
//}
//
//class Dog extends Animal{
//	public void bark() {
//		System.out.println("Dog are barking");
//	}
//}
//
//class Lion extends Animal{
//	public void veg() {
//		System.out.println("Lion is always eat vegeterian");
//	}
//}
//
//class Cat extends Animal{
//	public void milk() {
//		System.out.println("Cat is always dring milk");
//	}
//}
//}
