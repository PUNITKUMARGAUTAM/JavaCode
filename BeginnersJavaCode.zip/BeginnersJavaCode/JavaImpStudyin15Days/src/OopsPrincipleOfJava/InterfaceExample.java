package OopsPrincipleOfJava;


interface Animalss{
	void walk();
}

 class Dog implements Animalss{
	 
	 public void walk () {
		 System.out.println("Walks on 2 legs");
		 
	 }
 }
public class InterfaceExample {
	
	public static void main(String[] args) {
		
		Dog dg = new Dog();
		dg.walk();
	}

}
