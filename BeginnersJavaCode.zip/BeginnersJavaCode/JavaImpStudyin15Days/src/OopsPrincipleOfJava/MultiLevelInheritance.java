package OopsPrincipleOfJava;


class SingleShapeMultiLevel { 
	
	public void area() {
		System.out.println("display area");
	}
}
	class TriangleMultiLevel extends SingleShapeMultiLevel{
		
		public void area(int h, int l) {
			System.out.println(1/2*l*h);
		}
	}
	
	class EquleTriangle extends TriangleMultiLevel{     //
		public void area(int h, int l) {
			System.out.println(1/2*l*h);

		
		}
		
	}
public class MultiLevelInheritance {
	
	public static void main(String[] args) {
		
	}

}
