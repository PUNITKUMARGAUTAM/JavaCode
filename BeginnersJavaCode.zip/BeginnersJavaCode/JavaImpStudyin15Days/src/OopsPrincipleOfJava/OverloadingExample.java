package OopsPrincipleOfJava;

public class OverloadingExample {
	
	void sum(int a, long b) {
		System.out.println(a+b);
	}
	
	void sum(int a, int b , int c) {
		System.out.println(a+b+c);
	}
	
	public static void main(String[] args) {
		
	
	OverloadingExample oc= new OverloadingExample();
	
	oc.sum(12, 34);
	oc.sum(12,34,56);
	
}
	

}
