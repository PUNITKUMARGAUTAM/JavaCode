package OopsPrincipleOfJava;

class Bank {
	
	int gateRateIntrest() {
		return 0;
	}
}

class SBI extends Bank{
	int gateRateIntrest() {
		
		return 8;
	}
}

class ICICI extends Bank {
	int gateRateIntrest() {
		return 9;
	}
}

class Axis extends Bank {
	int gateRateIntrest() {
		return 10;
	}
	
}

public class OverridingExample {
	
	public static void main(String[] args) {
		
	
	
	SBI s= new SBI();
	ICICI ic= new ICICI();
	Axis ax= new Axis();
	
	System.out.println("SBI Rate of Interest: "+s.gateRateIntrest());
	System.out.println("ICICI Rate of Interest: "+ic.gateRateIntrest());  
	System.out.println("AXIS Rate of Interest: "+ax.gateRateIntrest());  
	
	}
	

}
