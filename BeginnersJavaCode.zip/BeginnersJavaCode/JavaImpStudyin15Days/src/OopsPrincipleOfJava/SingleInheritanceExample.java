package OopsPrincipleOfJava;


class SingleShape { 
	
	public void area() {
		System.out.println("display area");
	}
}
	class TriangleInherit extends SingleShape{
		
		public void area(int h, int l) {
			System.out.println(1/2*l*h);
		}
	}
	


public class SingleInheritanceExample {
	
	public static void main(String[] args) {
		
		Triangle t2= new Triangle();
		
		
		
	}

}
