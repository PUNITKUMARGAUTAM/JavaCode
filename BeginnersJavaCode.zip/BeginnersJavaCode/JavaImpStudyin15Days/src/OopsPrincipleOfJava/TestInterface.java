package OopsPrincipleOfJava;

interface I1 {
	
	void show();
	
}

interface I2 {
	
	void display();
}

interface I3 {
	 void printNamae();
}

public class TestInterface  implements I1, I2 ,I3 {
	
		
		@Override
		public void display() {
			System.out.println("Print display method");
			
		}

		@Override
		public void show() {
			System.out.println("Print show method");
			
		}

		@Override
		public void printNamae() {
			System.out.println("Print print method");
		}

		public static void main(String[] args) {
			
			TestInterface t= new TestInterface();
			t.show();
			t.display();
			
		}
}
