package SetExample;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetExample {
	
	public static void main(String[] args) {
		
		TreeSet<String> str= new TreeSet<String>();
		
		str.add("Rajat");
		str.add("Man");
		str.add("Mohan");
		
		Iterator<String> i= str.descendingIterator();
		
		while(i.hasNext()) {
			System.out.println(i.next());
		
			
	}
	}
}
