package SetExample;

import java.util.TreeSet;

public class TreeSetForFindingLowestAndHighestValue {
	
	public static void main(String[] args) {
		
		TreeSet<Integer> st= new TreeSet<Integer>();
		st.add(12);
		st.add(1);
		st.add(15);
        st.add(100);
		st.add(10);
		
		System.out.println("Print highets value=" + st.pollFirst());
		System.out.println("Print highets value=" + st.pollLast());
		

		
		
	}

}
