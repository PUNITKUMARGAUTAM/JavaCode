package TryWithResources;

class Door implements AutoCloseable{
	
	public void swing() {
		System.out.println("The door is swinging");
	}
	
	@Override
	public void close() {
		System.out.println("The door is closed");
	}
	
}

public class TryWithResourcesExample {

	public static void main(String[] args) {
		
		try (Door door = new Door()){
			door.swing();
		}
		
		catch(Exception e) {
			
		}
		
		finally{}
	}
}
