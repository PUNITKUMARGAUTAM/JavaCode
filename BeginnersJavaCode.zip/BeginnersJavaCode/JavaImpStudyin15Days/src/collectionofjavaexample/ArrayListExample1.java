package collectionofjavaexample;

import java.util.ArrayList;

public class ArrayListExample1 {
	
	public static void main(String[] args) {
		
		ArrayList <String> list= new ArrayList <String>();
		
		list.add("Raman");
		list.add("Rohit");
		list.add("Manmohan");
		list.add("Rajat");
		System.out.println(list);
	}

}
