package collectionofjavaexample;

import java.util.ArrayList;
import java.util.List;

public class GetandSetElementList {
	
	public static void main(String[] args) {
		
	
	
	//Creating a List  
	 List<String> list=new ArrayList<String>();  
	 //Adding elements in the List  
	 list.add("Mango");  
	 list.add("Apple");  
	 list.add("Banana");  
	 list.add("Grapes"); 
	 
	 System.out.println("returning element"+list.get(3));
	 list.set(3, "Roshan");
	 for(String fruit: list)
	 System.out.println(fruit);
		 
	 

}
}