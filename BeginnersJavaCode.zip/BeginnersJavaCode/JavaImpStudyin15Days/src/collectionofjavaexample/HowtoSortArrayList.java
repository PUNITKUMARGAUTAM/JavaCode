package collectionofjavaexample;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

//The java.util package provides a utility class Collections, which has the static method sort(). 
//Using the Collections.sort() method, we can easily sort the ArrayList.
public class HowtoSortArrayList {

	public static void main(String[] args) {
		
		List<String> list1= new ArrayList<String>();
		  list1.add("Mango");  
		  list1.add("Apple");  
		  list1.add("Banana");  
		  list1.add("Grapes");  
		  
		  Collections.sort(list1);
		  
		  for(String fruit:list1) 
			  System.out.println(fruit);
		  System.out.println("Sorting numbers--------------");
		  
		  List<Integer> list2= new ArrayList<Integer>();
		  list2.add(100);  
		  list2.add(81);  
		  list2.add(4);  
		  list2.add(2);
		  
		  Collections.sort(list2);
		  for(Integer number:list2)  
			    System.out.println(number);  
		  
		
	

	}

}
