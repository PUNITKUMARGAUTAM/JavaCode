package collectionofjavaexample;

import java.util.ArrayList;
import java.util.Iterator;

public class IteratingArrayListusingIterator {

	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("Mehar");
		list.add("Manmohan");
		list.add("Avanish");
		list.add("Deepak");
		 //Traversing list through Iterator 
		Iterator itr= list.iterator(); //getting the Iterator  
		while(itr.hasNext()) {  //check if iterator has the elements  
		System.out.println(itr.next()); //printing the element and move to next 

	}
	}
}
