package collectionofjavaexample;

import java.util.LinkedList;

public class LinkedListAdd {
	
	public static void main(String[] args) {
		
		LinkedList<String> link=new LinkedList <String>();
		link.add("Ravi");
		link.add("Vijay");
		link.add("Sankar");
		
		System.out.println("After invoking method of add(E e)method:"+link);
		
		link.add(1,"Gaurav");
		System.out.println("After invoking add(int index, E element) method: "+link);
		
		 LinkedList<String> link2=new LinkedList<String>();  
		 link2.add("Sonoo");  
		 link2.add("Hanumat"); 
		//Adding second list elements to the first list  
		 link2.addAll(link2);  
         System.out.println("After invoking addAll(Collection<? extends E> c) method: "+link2); 
         
         LinkedList<String> link3=new LinkedList<String>();  
         link3.add("John");  
         link3.add("Rahul");  
         //Adding second list elements to the first list at specific position  
         link2.addAll(1, link3);  
         System.out.println("After invoking addAll(int index, Collection<? extends E> c) method: "+link2); 
         
         link2.addFirst("Lokesh");  
         System.out.println("After invoking addFirst(E e) method: "+link2);  
         //Adding an element at the last position  
         link2.addLast("Harsh");  
         System.out.println("After invoking addLast(E e) method: "+link2);  
	}

}
