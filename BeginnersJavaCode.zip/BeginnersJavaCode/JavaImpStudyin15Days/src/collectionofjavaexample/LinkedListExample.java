package collectionofjavaexample;

import java.util.LinkedList;
import java.util.List;

class BookedName{
	
	public BookedName(int id, String name, String auther, String publisher, int quantity) {
		super();
		this.id = id;
		this.name = name;
		this.auther = auther;
		this.publisher = publisher;
		this.quantity = quantity;
	}
	int id;
	String name,auther,publisher;
	int quantity;
	
}
public class LinkedListExample {
	
	public static void main(String[] args) {
		
		List<BookedName> list= new LinkedList<BookedName>();
		
		BookedName b1= new BookedName(101,"Let us C","Yashwant Kanetkar","BPB",8);
		BookedName b2=new BookedName (102,"Data Communications & Networking","Forouzan","Mc Graw Hill",4);  
		BookedName b3=new BookedName(103,"Operating System","Galvin","Wiley",6);  
		
		list.add(b1);
		list.add(b2);
		list.add(b3);
		
		for(BookedName b:list) {
			System.out.println(b.id + " "+ b.name + " "+ b.auther + " " + b.publisher + "" + b.quantity + "");
		}
	}

}
