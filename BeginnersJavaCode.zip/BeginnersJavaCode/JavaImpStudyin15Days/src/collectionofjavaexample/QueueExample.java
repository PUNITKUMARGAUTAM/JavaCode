//package collectionofjavaexample;
//
//import java.util.concurrent.ConcurrentLinkedQueue;
//
//public class QueueExample {
//	
//	public static void main(String args[]) {
//		
//		ConcurrentLinkedQueue<Integer> queue= new ConcurrentLinkedQueue<Integer>();
//		
//		queue.add(12);
//		queue.add(13);
//		queue.add(15);
//		
//		queue.
//		
//		
//	}
//
//}
