package collectionofjavaexample;

import java.util.Iterator;
import java.util.LinkedList;

public class ReverseOfLinkedListString {
	
	public static void main(String[] args) {
		
		LinkedList<String> str= new LinkedList<String>();
		
		str.add("Mohan");
		str.add("Avanish");
		str.add("Praveen");
		
		Iterator itr=str.descendingIterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}

}
