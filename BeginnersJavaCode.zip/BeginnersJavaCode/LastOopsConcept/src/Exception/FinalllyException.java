package Exception;

public class FinalllyException {
	
	
	public static void main(String[] args) {
		
		try {
			
			System.out.println("Inside try block");
			
			int data=50/0;
			System.out.println(data);
		}
		
		catch(ArithmeticException ae) {
			System.out.println(ae);
		}
		
		
        finally {
			System.out.println("Finally Block always excuted");
		}
		
		System.out.println("Rest of the code");
	}

}
