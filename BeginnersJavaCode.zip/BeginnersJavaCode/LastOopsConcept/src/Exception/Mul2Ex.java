package Exception;

public class Mul2Ex {
	
	public static void main(String[] args) {
		
	
	
	try {
		
		String s=null;
		System.out.println(s.length());
	}
	
	catch(ArithmeticException e) {
		System.out.println("AE Exception");
	}
	
	catch(ArrayIndexOutOfBoundsException ae){
		System.out.println("Array Bound exception");
	}
	
	catch(Exception e) {
		System.out.println("Parent Exception");
	}
	
	System.out.println("Rest of the code");
	
	

}
}