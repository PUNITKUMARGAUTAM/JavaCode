package Exception;

public class MulCatch {
	
	public static void main(String[] args) {
		
	
	
	
	try {
		
		int arr[]= new int[5];
		
		arr[5]=30/0;
		System.out.println(arr[5]);
	}
	
	
catch(ArithmeticException e){
	
		System.out.println("Airthmatic exception occurs");
		
	}
	
	catch(ArrayIndexOutOfBoundsException e) {
		System.out.println("Index out of bound exception occurs");
	}
	
	catch(Exception e) {
		System.out.println("Parent exception");
	}
	
	System.out.println("Rest of the code");

}
}