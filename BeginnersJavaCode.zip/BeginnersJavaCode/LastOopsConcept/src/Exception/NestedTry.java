package Exception;

public class NestedTry {
	
	public static void main(String[] args) {
		
		try {
			
			try {
				
				System.out.println("Going to start nested try ");
				
				int b=39/0;
			}
			
			catch(ArithmeticException ae) {
				System.out.println(ae);
			}
			
			try {
				
				int a[]= new int [5];
				a[5]= 4;
			}
			
			catch(ArrayIndexOutOfBoundsException ae) {
				System.out.println(ae);
			}
			
			System.out.println("Other Statments");
		}
		
		catch(Exception ae) {
			System.out.println("handle the exception outer catch");
		}
		
		System.out.println("Normal flow");
	}

}
