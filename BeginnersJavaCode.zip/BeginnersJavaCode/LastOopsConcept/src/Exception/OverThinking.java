package Exception;


class  Animal12 {
	
	void name() {
		System.out.println("Hi name is Kiyara");
	}
}
	class Dog12 extends Animal12{
		
		
		void name() {
			super.name();
			System.out.println("Hi name is Vishal");
		}
	

	
}
		
		public class OverThinking{
			
			public static void main(String[] args) {
				
				Animal12 ac= new Dog12();
				ac.name();
				
			}
		}



