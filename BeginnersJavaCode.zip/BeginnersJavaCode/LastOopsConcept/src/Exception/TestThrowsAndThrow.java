package Exception;

public class TestThrowsAndThrow {
	
	public static void method() throws ArithmeticException
	{
		
		System.out.println("Inside method");
		
		throw new ArithmeticException("Throwing exception method");
	}
	
	public static void main(String[] args) {
		
	
	
	try {
		
		method();
	}
	
	catch(ArithmeticException ae) {
		System.out.println("Caught in main method");
	}

}
}