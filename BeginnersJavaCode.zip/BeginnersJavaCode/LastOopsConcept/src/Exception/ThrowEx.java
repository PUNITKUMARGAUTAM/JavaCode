package Exception;

import java.security.DomainCombiner;

public class ThrowEx {
	
	public static void validate(int age) {
		
		if(age<18) {
			
			throw new ArithmeticException("Person is not validate to vote");
		}
		
		else {
			
			System.out.println("Welcome to vote");
			
		}
		
		
	}
	
	public static void main(String[] args) {
		
		validate(15);
		System.out.println("Rest of the code");
	}

}
