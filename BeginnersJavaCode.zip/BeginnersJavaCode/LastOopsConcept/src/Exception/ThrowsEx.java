package Exception;

public class ThrowsEx {
	
	public static int divideNum(int n, int m) throws ArithmeticException{
		
		int div=n/m;
		
		return div;
	}
	
	public static void main(String[] args) {
		
		ThrowsEx ts= new ThrowsEx();
		
		try {
			
			System.out.println(ts.divideNum(10, 0));
		}
		
		catch(ArithmeticException ae) {
			System.out.println("Number can't not be divided by zero");
		}
		
		System.out.println("Rest of the code");
	}

}


