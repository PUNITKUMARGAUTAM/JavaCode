package Exception;

public class TryEx {
	
	public static void main(String[] args) {
		
//		int i=100;
//		int j=0;
//		int divide;
//		
//		try {
//			
//			 divide=i/j;
//		}
//		
//		catch(Exception e) {
//			System.out.println(i/(j+2));
//		}
		
		
		
		try {
			
			int arr[]= {1,2,3,4,5};
			System.out.println(arr[10]);
		}
		
		catch(Exception e) {
			System.out.println(e );
		}
		
		
		
		System.out.println("Rest of the code");
	




try {
	int d=100/0;
	
	
}

catch(Exception e) {
	System.out.println(e);
}


}
}