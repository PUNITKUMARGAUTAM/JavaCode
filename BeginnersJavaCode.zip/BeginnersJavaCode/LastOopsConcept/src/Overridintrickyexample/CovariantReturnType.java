package Overridintrickyexample;

class Father {
	
	Father display() {
		System.out.println("Parents method");
		return this;
	}
}


class FatherChild extends Father {
	 
	@Override
	FatherChild display() {
		System.out.println("Child method");
		
		return this;
	}
	
	
}
public class CovariantReturnType {
	
	public static void main(String[] args) {
		
		Father f= new Father();
		f.display();
		
		FatherChild fc= new FatherChild();
		fc.display();
		
		Father fc1= new FatherChild();
		fc.display();
	}

}
