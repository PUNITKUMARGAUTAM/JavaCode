package Overridintrickyexample;

class MultipleAccess {
	
	protected void display() {
		System.out.println("Parent method");
	}
	
}

class ChildMultipleAccess extends MultipleAccess {
	
	@Override
	public void display() {
		System.out.println("Child method");
	}
}

public class DiffrentAccessSpecifier {
	
	public static void main(String[] args) {
		
		MultipleAccess mc= new ChildMultipleAccess();
		mc.display();
		
	}

}
