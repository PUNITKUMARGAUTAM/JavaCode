package Overridintrickyexample;

class FinalParent {
	
	final void display() {
		System.out.println("final parent's method");
	}
}

class FinalChild extends FinalParent {
	
//	final void display() {  getting compilation error when override final method
//		
//	}
	
}

public class FinalKeyWordWithOverriding {
	
	public static void main(String[] args) {
		
		FinalParent obj= new FinalChild();
		obj.display();
	}

}
