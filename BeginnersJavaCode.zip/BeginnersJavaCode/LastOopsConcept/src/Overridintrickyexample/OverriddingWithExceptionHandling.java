package Overridintrickyexample;

class OverrrideWithExc {
	
	void display() throws Exception {
	System.out.println("Parent method");
}
}

class ChildOvverideWithExc extends OverrrideWithExc {
	
	@Override
	void display() throws Exception {
		
		System.out.println("Child method");
		
	}
}
public class OverriddingWithExceptionHandling {
	
	public static void main(String[] args) {		
		OverrrideWithExc ov= new ChildOvverideWithExc();
		
		
		
		try {
			ov.display();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
