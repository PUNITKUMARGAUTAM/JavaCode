package Overridintrickyexample;


class Annotation {
	void display() {
		System.out.println("@Ovveride parents method using");
	}
}

class ChildAnnotaion extends Annotation{
	
	@Override
	void display() {
		System.out.println("Child method");
	}
	
	
}

public class OverrideAnnotation {
	
	public static void main(String[] args) {
		
		Annotation an= new ChildAnnotaion();
		an.display();
	}

}
