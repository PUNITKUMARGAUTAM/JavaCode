package Overridintrickyexample;


class OverPvtMethod {
	
	private void display() {
		System.out.println("Parents private methods");
	}
	
	 void show() {
		display();
	}
}

class ChildPvtMethod extends OverPvtMethod {
	
	private void display() {
		System.out.println("Child private method");
		
		
			display();
		}
	}


public class OverrideWithPrivateMethod {
	
	public static void main(String[] args) {
		
		OverPvtMethod pv= new OverPvtMethod();
		pv.show();
		
		ChildPvtMethod ch= new ChildPvtMethod();
		ch.show();
	}

}
