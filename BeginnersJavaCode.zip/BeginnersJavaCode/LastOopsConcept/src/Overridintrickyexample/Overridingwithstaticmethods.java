package Overridintrickyexample;


class Parent{
	
	static void display() {
		System.out.println("Parent's static");
	}
}

class Child extends Parent {
	
	static void display() {
		System.out.println("Child object");
	}
}

public class Overridingwithstaticmethods {
	
	public static void main(String[] args) {
		
		Parent obj1= new Parent();
		obj1.display();
		
		Parent obj2= new Child();
		obj2.display();
		
		Child obj3= new Child();
		obj3.display();
	}

}
