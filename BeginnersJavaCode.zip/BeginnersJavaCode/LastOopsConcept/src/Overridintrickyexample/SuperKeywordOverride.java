package Overridintrickyexample;


class SuperParent {
	
	void display() {
		System.out.println("Parent's method");
	}
}

class SuperChild extends SuperParent{
	
	void display() {
     super.display();
		System.out.println("Childs method");
	}
}
public class SuperKeywordOverride {
	
	public static void main(String[] args) {
		
		SuperChild sc= new SuperChild();
		sc.display();
	}
	
	

}
