package Revision;

abstract class Banker{
	abstract int intrest();
}

class Axis extends Banker{
	
	int intrest() {
		return 10;
	}
}

class BOB extends Banker{
	
	int intrest() {
		return 12;
	}
}
public class AbstrcatClassEx {
	
	public static void main(String[] args) {
		
		Banker ax= new Axis();
		System.out.println("rate of intreest"+ ax.intrest());
		
		Banker pb= new BOB();
		System.out.println("rate of intrest"+ pb.intrest());
	}

}
