package Revision;

class Pen{
	
	int id;
	
	String name;
	
	void insert(int i, String n) {
		id=i;
		name=n;
	}
	
	void display() {
		System.out.println(id + "=" +name);
	}
	
}



public class ClassObjectExample {
	
	public static void main(String[] args) {
		
	
	
	Pen n= new Pen();
	n.insert(10, "Raju");
	n.display();
	}
	
	

}
