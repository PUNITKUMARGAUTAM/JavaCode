package Revision;

 class OwnException extends Exception {
	
	public OwnException(String s) {
		
		super(s);
		
	}

}

public class CustomeException{
	
	public static void main(String[] args) {
		
		
		try {
			 throw new OwnException("GeeksforGeeks");
			 
			 
		}
		
		catch(OwnException ex) {
			System.out.println("Cought");
			
			System.out.println(ex.getMessage());
		}
		
	
	}
	
}

//o/p= cought, geeksfoegeeks


class OwnException1 extends Exception {
	
	
		
	}


 class CustomeException2{
	
	public static void main(String[] args) {
		
		
		try {
			 throw new OwnException1();
			 
			 
		}
		
		catch(OwnException1 ex) {
			System.out.println("Cought");
			
			System.out.println(ex.getMessage());
		}
		
	
	}
	
}
