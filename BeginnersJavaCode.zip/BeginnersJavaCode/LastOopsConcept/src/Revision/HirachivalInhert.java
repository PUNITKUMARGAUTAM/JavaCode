package Revision;

class Fruits{
	
	void eat() {
		System.out.println("Every eat fruitrs");
	}
}

class Banana extends Fruits{
	
	void bn() {
		System.out.println("Evryone eat bananan");
	}
}

class Apple extends Fruits{
	
	void apl() {
		System.out.println("Eat apple");
	}
}
public class HirachivalInhert {
	
	public static void main(String[] args) {
		
		Apple ap= new Apple();
		ap.eat();
		ap.apl();
	
	}

}
