package Revision;

public class IllegalException {
	
	public static void main(String[] args) {
		
		int age=12;
		
		if(age >=18) {
			System.out.println("Valid for vote");
		}
		
		else {
			
			throw new IllegalArgumentException("Not valid for vote");
			
//			System.out.println("Not valid for vote");
		}
	}

}
