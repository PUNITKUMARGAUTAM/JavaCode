package Revision;


interface Arts {
	void draw();
}


class Rectangle implements Arts{
	

	public void draw() {
		System.out.println("Drawing");
	}
}

class Circle implements Arts{
	
	public void draw() {
		System.out.println("Drawing circle");
	}
}
public class InterfaceExamp {
	
	public static void main(String[] args) {
		
		Rectangle d= new Rectangle();
		d.draw();
		
		Circle b= new Circle();
		b.draw();
	}

}
