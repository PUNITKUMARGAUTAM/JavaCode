package Revision;

interface Father {
	
	void speak();
}

interface Son{
	void listen();
}

public class MulInheritance  implements Father, Son{
	
	public void speak() {
		System.out.println("Hello");
	}
	
	public void listen() {
		System.out.println("Welcome");
	}
	
	public static void main(String[] args) {
		
		MulInheritance ml= new MulInheritance();
		ml.speak();
		ml.listen();
		
	}

}
