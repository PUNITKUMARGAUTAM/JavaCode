package Revision;

class Animal {
	void eat() {
		System.out.println("Eating");
	}
}

class Lion extends Animal{
	void king() {
		System.out.println("King of forest");
	}
	
	
}

class BabyLion extends Lion{
	
	void smallKing() {
		System.out.println("Smnall kingof forest");
	}
}

public class MultiLevaleInhert {
	
	public static void main(String[] args) {
		

	
	
	BabyLion bl= new BabyLion();
	bl.smallKing();
	bl.king();
	bl.eat();
	

}
}
