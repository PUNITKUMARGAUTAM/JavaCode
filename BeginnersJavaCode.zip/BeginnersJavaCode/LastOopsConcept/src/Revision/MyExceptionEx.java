package Revision;

public class MyExceptionEx  extends Exception {
	
	
	private static int accNo[]= {10,20,30,40};
	
	private static String name[]= {"Rajat", "Manmohan","Surya","Ajeet","Abhi"};
	
	private static double bal[]= {1300.0, 10000.0, 20000.0, 60000.0};
	
	public MyExceptionEx() {
		
	}
	
	MyExceptionEx(String str){
		super(str);
	}
	
	public static void main(String[] args) {
		
		try {
			
			System.out.println("AccNO"+ "\t" + "Name" + "\t" + "Balance" + "\t");
			
			for(int i=0; i<=5; i++) {
				System.out.println(accNo[i] + "\t" + name[i] + "\t" + bal[i]);
				
				if(bal[i] <1000) {
					
					MyExceptionEx me= new MyExceptionEx("Balance is less tha 10000");
					
					throw me;
				}
			}
		}
		
		catch(MyExceptionEx e) {
			e.printStackTrace();
			
		}
	}
	
	
	

}
