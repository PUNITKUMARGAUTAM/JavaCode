package Revision;

public class Over {
	
	public static void main(String[] args) {
	      for(int i = 0; i<10; i++){
	i++;
	
	System.out.println(i);
	}
	

	}

}
