package Revision;

public class OverloadPoly {
	
	void add(int a, long b) {
		System.out.println(a+b);
	}
	
	void add(int a, int b, int c ) {
		System.out.println(a+b+c);
	}
	
	public static void main(String[] args) {
		
		OverloadPoly ob= new OverloadPoly();
		ob.add(10, 20);
		ob.add(10,20,30);
	}

}
