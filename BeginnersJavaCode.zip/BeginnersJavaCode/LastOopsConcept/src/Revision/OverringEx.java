package Revision;


class Bank{
	
	int intrestOf() {
		return 0;
	}
}

class UBI extends Bank  {
	
	int intrestOf() {
		return 10;
	}
	
}

class SBI extends Bank{
	int intrestOf() {
		return 30;
	}
}

class PNB extends Bank{
	int intrestOf() {
		return 40;
	}
}

public class OverringEx {
	
	public static void main(String[] args) {
		
		UBI ub= new UBI();
		SBI sb= new SBI();
		PNB pb= new PNB();
		
		System.out.println("ub rate "+ ub.intrestOf());
		System.out.println("sb rate "+ sb.intrestOf());
		System.out.println("pb rate "+ pb.intrestOf());
		
	}

}
