package Revision;


class BoBBank {
	
	int gateRateOfintres() {
		return 0;
	}
}


class AB extends BoBBank{
	
	int gateRateOfintres() {
		return 10;
	}
}

class BC extends BoBBank {
	int gateRateOfintres() {
		return 12;
	}
}

class CB extends BoBBank {
	
	int gateRateOfintres() {
		return 15;
	}
	
}
public class OvveriddingEcxample extends BoBBank {
	
//	super();

	

	
	public static void main(String[] args) {
		
		BoBBank bb= new BoBBank();
		bb.gateRateOfintres();
		
		AB ab= new AB();
		BC bc= new BC();
		CB cb= new CB();
		
		System.out.println("Intrest of AB"+ ab.gateRateOfintres());
		System.out.println("Intrest of BC"+ bc.gateRateOfintres());
		System.out.println("Intrest of CB"+ cb.gateRateOfintres());
	}

}




