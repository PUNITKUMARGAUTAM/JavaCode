package Revision;

public class ScopeOfClassLevel {
	
	
	public String pname;
	private double pprice;
	
	
	public ScopeOfClassLevel(String name) {
		pname=name;
	}
	
	public void setPrice(double price) {
		pprice=price;
	}
	
	public void getInfo() {
		System.out.println("name"+ pname);
		System.out.println("price"+ pprice);
		
		}
	
	public static void main(String[] args) {
		
		ScopeOfClassLevel sc= new ScopeOfClassLevel("Rohit");
		sc.setPrice(100000);
		sc.getInfo();
	}
	

}








//class Demo {
//	
//	void show() {
//		int x=10;
//		System.out.println("the value of " + x);
//		}
//	
//	public static void main(String[] args) {
//		
//		Demo cd= new Demo();
//		cd.show();
//	}
//}

//
//
//class StaticVariable{
//	
//	private static double pivalue;
//	public static final String piconstants="pi";
//	
//	public static void main(String[] args) {
//		
//		pivalue=3.14456789;
//		
//		System.out.println("The value pf " + piconstants + "is" + pivalue);
//	}
//}


