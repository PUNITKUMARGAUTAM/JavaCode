package Revision;

class Human {
	
	void speak() {
		System.out.println("Speaking");
	}
}

class Amit extends Human{
	void walk() {
		
		System.out.println("Walking");
		
	}
}

public class SingleInhert {
	
	public static void main(String[] args) {
		
		Amit ah= new Amit();
		ah.walk();
		ah.speak();
	}

}
