package Revision;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

public class ThrowsException {
	
	public static void main(String[] args) throws IOException {
		
		FileReader file= new FileReader("C:\\test\\a.txt");
		
		BufferedReader biff=new BufferedReader(file);
		
		for(int count=0; count<3; count++) {
			
			System.out.println(biff.readLine());
			
			biff.close();
		}
			
		}
	

}


class UncheckedEx {
	
	public static void main(String[] args) {
		
		int x=0;
		int y=10;
		int c=10;
		
		int result;
		
		try {
			result= x/(y-c);
		}
		
		catch(ArithmeticException e) {
			System.out.println("Exception cought : Divide by zero");
		}
		
		finally {
			System.out.println("I am in finnaly block");
		}
	}
}


class ThrowsExce {
	
	static void fun() throws IllegalAccessException {
		
		System.out.println("Inside fun()");
		
		throw new IllegalAccessException("demo");
		
	}
	public static void main(String[] args) {
		
		try {
			fun();
		}
		
		catch(IllegalAccessException e) {
			System.out.println("Caught in main");
		}
	}
	
}
