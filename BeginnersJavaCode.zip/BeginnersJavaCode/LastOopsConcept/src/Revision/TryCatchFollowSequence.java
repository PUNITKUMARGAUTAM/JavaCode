package Revision;

public class TryCatchFollowSequence {
	
	public static void main(String[] args) {
		
		int[] arr= new int[4];
		
		try {
			int i=arr[4];
			
			System.out.println("Inside try block");
		}
		
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Caought in catch block");
		}
		
		finally{
			
			System.out.println("In finnaly block");
			
		}
		
		System.out.println("Outside try catch block");
	}

}

//class tst
//{
//    public static void main(String[] args)throws InterruptedException
//    {
//        Thread.sleep(10000);
//        System.out.println("Hello Geeks");
//    }
//}
