package ScopeOfVariable;

public class Product {
	
	public String pName;
	private double pPrice;
	
	public Product(String pname) {
		pName=pname;
	}
	
	public void setPrice(double pprice) {
		pPrice=pprice;
	}

	void getInf() {
		System.out.println("product name= "+ pName);
		System.out.println("Price value= " + pPrice);
	}
	
	
	public static void main(String[] args) {
		
		Product p= new Product("Raju");
		p.setPrice(12900);
		p.getInf();
	}
}
