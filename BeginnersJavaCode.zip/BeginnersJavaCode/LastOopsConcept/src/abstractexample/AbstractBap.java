package abstractexample;

abstract class Apple{
	
	abstract void sound();
}

abstract class Banana extends Apple{
	void sound() {
		System.out.println("Fruits is very sweets");
	}
}
	
	class Mango extends Banana{
		
	
}

public class AbstractBap {
	
	public static void main(String[] args) {
		
		Mango ab= new Mango();
		ab.sound();
	}

}
