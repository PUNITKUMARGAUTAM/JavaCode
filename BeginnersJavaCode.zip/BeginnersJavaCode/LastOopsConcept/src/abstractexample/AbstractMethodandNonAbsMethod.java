package abstractexample;


abstract class Animal {
	
	abstract void sound();
	
	void sleep() {
		System.out.println("Animal is sleeping");
	}
}

class Dog extends Animal{
	
	void sound() {
		System.out.println(" Dog barks ");
	}
}
public class AbstractMethodandNonAbsMethod {
	
	public static void main(String[] args) {
		
		Animal ac= new Dog();
		ac.sound();
		ac.sleep();
	}

}
