package abstractexample;

import java.util.ArrayList;

abstract class Computer {
	
	abstract void sound();
	
}

class Laptop extends Computer{
	
	void sound() {
		System.out.println("Soundl is very slow of laptop");
	}
}

public class AbstractUsingArrayList {
	
	public static void main(String[] args) {
		
		ArrayList<Computer> ac= new ArrayList<>();
		ac.add(new Laptop());
		
		for(Computer cm : ac) {
			cm.sound();
		}
	}

}
