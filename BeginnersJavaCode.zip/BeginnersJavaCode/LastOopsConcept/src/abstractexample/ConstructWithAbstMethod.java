package abstractexample;

abstract class AbsConstruct{
	
	 AbsConstruct() {
		
	}
	 
	 abstract void start();
}

class ImpAbsr extends AbsConstruct{
	
	public void start() {
		System.out.println("Car is started");
	}
}
public class ConstructWithAbstMethod {
	
	public static void main(String[] args) {
		
		AbsConstruct ab= new ImpAbsr();
		ab.start();
	}

}
