package abstractexample;

interface Vechile{
	
	void stop();
	
	void start();
}

class Car implements Vechile{
	
	public void start() {
		System.out.println("Car is started");
	}
	
	public void stop() {
		System.out.println("Car is stopped");
	}
}
public class InterfaceExample {
	
	public static void main(String[] args) {
		
		Vechile cr = new Car();
		cr.start();
		cr.stop();
	}

}
