package abstractexample;


abstract class Human {
	
	abstract void eat();


 static void food() {
	System.out.println("human need food for living");
}
}

class Boy extends Human{
	
	void eat() {
		System.out.println("Boy drink milk");
	}
}
public class StaticAbstract {
	
	public static void main(String[] args) {
		
		Boy by= new Boy();
		by.eat();
		Human.food();
	}

}
