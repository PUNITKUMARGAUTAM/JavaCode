package exceptionhandling;

public class DatabaseConnectionExample {
	
	
//	    public static void main(String[] args) {
//	        // Database connection details
//	        String url = "jdbc:mysql://localhost:3306/mydatabase";
//	        String username = "root";
//	        String password = "password";
//	
//	        // Try-with-resources statement
//	        try (Connection connection = DriverManager.getConnection(url, username, password)) {
//	            // Code to be executed within the try block
//	
//	            // Perform database operations here
//	
//	            System.out.println("Connected to the database.");
//	        } catch (SQLException e) {
//	            // Exception handling code
//	            e.printStackTrace();
//	        }
//	    }
	}


