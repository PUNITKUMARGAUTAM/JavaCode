package exceptionhandling;

public class FinallyAfterCatchExample {
	
	public static void main(String[] args) {
		
		try {
			
			int reslut=10/0;
		}
		
		
		catch(ArithmeticException ae) {
			System.out.println("Caught exception");
		}
		
		finally {
			System.out.println("Finally block");
		}
	}

}
