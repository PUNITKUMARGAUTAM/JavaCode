package exceptionhandling;

public class FinallyOrderExample {
	
	public static void main(String[] args) {
		
		try {
			
			System.out.println("Try block");
			throw new Exception();
			
		}
		catch(Exception e) {
			System.out.println("Catch block");
		}
		
		finally{
			System.out.println("Finally block");
		}
	}
	
}	
//	// exceptions in a specific order
//	 public static void main(String[] args) {
//	        try {
//	            int result = Integer.parseInt("abc"); // Throws NumberFormatException
//	        } catch (RuntimeException e) {
//	            System.out.println("Runtime exception caught");
//	        } catch (Exception e) {
//	            System.out.println("Exception caught");
//	        }
//	    }
//
//}
