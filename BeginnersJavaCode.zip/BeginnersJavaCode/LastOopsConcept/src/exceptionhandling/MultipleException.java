package exceptionhandling;

//public class MultipleException {
//	
//	public static void main(String[] args) {
//		
//		try {
//			
//			String str= null;
//			System.out.println(str.length());
//			
//			int[] arr= new int[5];
//			System.out.println(arr[10]);
//		}
//		
//		catch(NullPointerException | IndexOutOfBoundsException ex) {
//			System.out.println("Cought exception");
//		}
//		
//		finally {
//			 System.out.println("Always executed finally block");
//		}
//	}
//
//}



public class MultipleException {
    public static void main(String[] args) {
        try {
            int[] arr = new int[5];
            System.out.println(arr[10]); // Throws ArrayIndexOutOfBoundsException
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException caught");
        } catch (Exception e) {
            System.out.println("Exception caught");
        }
    }
}