package exceptionhandling;

public class NestedTryCatchBlock {
	
	public static void main(String[] args) {
		
		try {
			
			try {
				
				int result=Integer.parseInt("ABC");
				
			}
			catch(NumberFormatException e) {
			System.out.println("Inner block  Number format exception caught ");
			
			throw new ArithmeticException("Arithmatic exception occured");
		}
		}
		
		catch(ArithmeticException e) {
			System.out.println("Outer catch block: Arithmatic exception caught");
		}
	}

}
