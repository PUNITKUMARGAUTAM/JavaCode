package exceptionhandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ResourceClosingExampleFile {
	
	public static void main(String[] args) {
		
		FileInputStream file=null;
		try {
			
			file= new FileInputStream("file.txt");
		}
		
		catch(FileNotFoundException ex) {
			System.out.println("File not found");
		}
		
		finally {
			
			try {
				if(file !=null) {
					file.close();
				}
			}
				catch(IOException ex) {
					System.out.println("Error occured while closing file");
				}
			}
		}
	}


