package exceptionhandling;

public class RethrowExceptionExample {
	
//	public static void main(String[] args) throws AgeValidationException {
//		
//		try {
//			
//			validateAge(15);
//				
//			
//		}
//			catch(AgeValidationException e) {
//				System.out.println("Caught AgeValidationException");
//				throw e;
//			}
//		
//	}
//	
//		public static void validateAge(int age) throws AgeValidationException{
//			
//			if(age <18) {
//				throw new AgeValidationException("Invalid age");
//			}
//		}
//	}
//
//	class AgeValidationException extends Exception{
//		
//		public AgeValidationException(String message) {
//			super(message);
//		}
//	}

	
	
	    public static void main(String[] args) throws AgeValidationException {
	        try {
	            validateAge(15); // Throws AgeValidationException
	        } catch (AgeValidationException e) {
	            System.out.println("Caught AgeValidationException");
	            throw e; // Rethrow the exception
	        }
	    }

	    public static void validateAge(int age) throws AgeValidationException {
	        if (age < 18) {
	            throw new AgeValidationException("Invalid age");
	        }
	    }
	}

	class AgeValidationException extends Exception {
	    public AgeValidationException(String message) {
	        super(message);
	    }
	}

	

