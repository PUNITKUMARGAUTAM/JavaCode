package exceptionhandling;

public class RethrowExceptionForPractice {
	
	public static void main(String[] args) {
		
		try {
			
			getData();
			getData1();
		}
		
		catch(ArithmeticException ex) {
			System.out.println("Handled in main method");
		}
	}
	
	static void getData() {
		
		try {
			
			int a=100/50;
			System.out.println("A== "+ a);
			
		}
		
		catch(ArithmeticException ex1) {
			throw ex1;
		}
		
	}
		static void getData1() {
			try {
				
				int b=100/0;
				System.out.println("B"+ b);
				}
			catch(ArithmeticException ex) {
				throw ex;
			}
		
	}

}
