package exceptionhandling;

public class SeparateCatchBlocksExample {
	
	 public static void main(String[] args) {
	        try {
	            int result = Integer.parseInt("abc"); // Throws NumberFormatException
	        } catch (NumberFormatException e) {
	            System.out.println("NumberFormatException caught");
	        } catch (ArithmeticException e) {
	            System.out.println("ArithmeticException caught");
	        }
	    }

}
