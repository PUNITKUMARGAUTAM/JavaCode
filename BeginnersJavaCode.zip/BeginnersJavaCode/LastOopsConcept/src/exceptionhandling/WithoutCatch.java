package exceptionhandling;

import java.io.IOException;

//public class WithoutCatch {
	
	// code for without catch
	
//	public static void main(String[] args) {
//		
//		try {
//			
//			int n=10/0;
//		}
//		
//		finally {
//			System.out.println("Finally block executed");
//		}
//	}
//
//}


// for using super class of exception
//public class WithoutCatch {
//    public static void main(String[] args) {
//        try {
//            int result = 10 / 0; // Throws ArithmeticException
//        } catch (Exception e) {
//            System.out.println("Exception caught");
//        }
//    }
//}



public class WithoutCatch {
    public static void main(String[] args) throws IOException {
        readFromFile("myfile.txt");
    }

    public static void readFromFile(String filename) throws IOException {
        // Read from the file
    }
}