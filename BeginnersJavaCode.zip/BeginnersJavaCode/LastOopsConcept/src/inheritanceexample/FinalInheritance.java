//package inheritanceexample;
//
//final class Bap {
//	
//	void display() {
//		System.out.println("Bap ji active");
//	}
//}
//
//public class FinalInheritance extends Bap { // can not inherit final class
//	
//	void display() {
//		System.out.println("Childs class ");
//	}
//	
//	public static void main(String[] args) {
//		
//		FinalInheritance fh= new FinalInheritance();
//		fh.display();
//	}
//
//}
