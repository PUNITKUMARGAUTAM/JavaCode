package inheritanceexample;


class College{
	void display() {
		System.out.println("College is parent class of school");
	}
}

public class MethodHiding extends College {
	
	void display() {
		System.out.println("School name is DPS");
	}
	
	public static void main(String[] args) {
		
		College mc= new MethodHiding();
		mc.display();
	}
	
	

}

//abstract class Shape {
//    abstract void draw();
//}
//
//class Rectangle extends Shape {
//    void draw() {
//        System.out.println("Drawing a rectangle");
//    }
//}
//
//class Circle extends Shape {
//    void draw() {
//        System.out.println("Drawing a circle");
//    }
//}
//
//class Main {
//    public static void main(String[] args) {
//        Shape rect = new Rectangle();
//        Shape circle = new Circle();
//        rect.draw();
//        circle.draw();
//    }
//}
