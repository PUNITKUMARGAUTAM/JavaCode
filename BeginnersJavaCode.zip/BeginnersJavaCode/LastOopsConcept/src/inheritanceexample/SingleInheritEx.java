package inheritanceexample;


class Parent{
	
	void display() {
		System.out.println("Parent class");
	}
}

class Child extends Parent{
	
}
public class SingleInheritEx {
	
	public static void main(String[] args) {
		
		Child ch=new Child();
		ch.display();
	}

}
