package inheritanceexample;

import java.security.DomainCombiner;

class AddPrint {
	int x=10;
}

public class SuperKeywordInheritance extends AddPrint  {
	
	int x=20;
	
	void display() {
		System.out.println("Child of x="+ x);
		
		System.out.println("Parent class="+ super.x);
		
		}
	
	public static void main(String[] args) {
		
		SuperKeywordInheritance sk= new SuperKeywordInheritance();
		sk.display();
	}

}
