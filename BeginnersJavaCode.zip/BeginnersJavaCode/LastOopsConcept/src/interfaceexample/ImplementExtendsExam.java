//package interfaceexample;
//
////interface MyyInterface {
////	
////	void print();
////}
//// class MyyParent {
////	
////	void print() {
////		System.out.println("Parents method class");
////	}
////}
////
////class MYChild extends MyyParent implements MyyInterface{
////	
////	
////}
////
////public class ImplementExtendsExam {
////	
////	public static void main(String[] args) {
////		
////		MYChild my= new MYChild();
////		my.print();
////	}
////
////}
//
//
//interface MyInterface1 {
//    void myMethod();
//}
//
//public class MyParentClass12 {
//    void myMethod() {
//        System.out.println("Parent class method");
//    }
//}
//
//class MyClass1 extends MyParentClass12 implements MyInterface1 {
//}
//
//public class ImplementExtendsExam {
//    public static void main(String[] args) {
//        MyClass1 obj = new MyClass1();
//        obj.myMethod();
//    }
//}
