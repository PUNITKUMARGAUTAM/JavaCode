package interfaceexample;

interface OwnInterface {
	
	abstract int getInfo();
}

class MyClass implements OwnInterface
{
	public int getInfo() {
		return 10;
	}
}
public class Overridedefaultmethod {
	
	public static void main(String[] args) {
		
		OwnInterface ow= new MyClass();
		System.out.println(ow.getInfo());
	}

}


//interface PrInterface {
//	
//	void showMethod();
//}
//
//class MyShow {
//	
//	void showMethod() {
//		System.out.println("Class method");
//	}
//	
//	public class MainClass {
//		public static void main(String[] args) {
//			
//			MyShow pf= new MyShow();
//			pf.showMethod();
//		}
//	}
//}