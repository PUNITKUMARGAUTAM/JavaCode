package interfaceexample;

interface MyInterface {
	
	default void display() {
		System.out.println("Default method");
	}
}

class Test implements MyInterface {
	
	public void display() {
		System.out.println("Override method");
	}
}

public class TestInterface {
	
	public static void main(String[] args) {
		
		MyInterface my= new Test();
		my.display();
	}

}
