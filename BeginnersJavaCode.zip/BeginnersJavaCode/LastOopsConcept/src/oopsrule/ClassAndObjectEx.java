package oopsrule;


//class Student {
	
//	int rollno;
//	String name;
//
//
//void insertData(int r, String n) {
//	
//	rollno=r;
//	name=n;
//	
//}
//
//void displayInf() {
//	System.out.println(rollno + " " + name);
//}
//}
//public class ClassAndObjectEx {
//	
//	public static void main(String[] args) {
//		
//		Student s= new Student();
//		Student s1= new Student();
//		
//		s.insertData(101, "Dubey");
//		s1.insertData(12, "Bhim");
//		
//		s.displayInf();
//		s1.displayInf();
//	}
	
	
class Boy {
	int id;
	String name;
	
	void insert(int d, String n){
		id=d;
		name=n;
	}
	
	public void display() {
		System.out.println(id + " " + name);
	}
}
	class ClassAndObjectEx{
	public static void main(String[] args) {
		
		
		
		Boy s= new Boy();
		Boy s1= new Boy();
		
		s.insert(12, "Rohit");
		s1.insert(23, "Rohan");
		
		s.display();
		s1.display();

		
		
	
	}
	}
