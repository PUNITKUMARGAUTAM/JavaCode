package overloadingexampole;

public class AutoBoxingAndWidening {
	
	void display(int num) {
		System.out.println("Print int value=" + num);
	}
	
	void display(Integer num1) {
		System.out.println("Print num1 value=" + num1);
	}
	
	void display(double num2) {
		System.out.println("Print double value=" + num2);
	}
	
	public static void main(String[] args) {
		
		AutoBoxingAndWidening ab= new AutoBoxingAndWidening();
		ab.display(10.9078);
		ab.display(100);
		ab.display(new Integer(20));
	}

}
