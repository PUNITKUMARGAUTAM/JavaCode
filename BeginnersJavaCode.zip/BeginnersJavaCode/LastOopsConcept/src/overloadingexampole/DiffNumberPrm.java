package overloadingexampole;

public class DiffNumberPrm {
	
	
	void display(int num, String str) {
		System.out.println("Number of int=" + num + ",String value of=" + str);
		
	}
	
	void display(double num1, int num2) {
		System.out.println("Double value="+ num1 + ",Int valeu of number=" + num2);
	}
	
	public static void main(String[] args) {
		
		DiffNumberPrm nc= new DiffNumberPrm();
		nc.display(1.34, 12);
		nc.display(15, "Rohit");
	}

}
