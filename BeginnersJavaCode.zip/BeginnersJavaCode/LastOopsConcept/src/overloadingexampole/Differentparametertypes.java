package overloadingexampole;

public class Differentparametertypes {
	
	
	void display(int num) {
		System.out.println("Num of int="+ num);
	}
	
	void display(String str) {
		System.out.println("Stirng value="+ str);
	}
	
	public static void main(String[] args) {
		
	
		Differentparametertypes df = new Differentparametertypes();
		df.display(10);
		df.display("WTT");
	

}
}