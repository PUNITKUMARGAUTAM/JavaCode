package overloadingexampole;

public class DiifReturnType {
	
	
	
	 int  add(int num1 , int num2) {
		 return num1+ num2;
		
	}
	 
	 double add (double n1 , double n2) {
		 return n1+n2;
	 }
	 
	 public static void main(String[] args) {
		
		 DiifReturnType cm= new DiifReturnType();
		System.out.println("print add"+cm.add(10, 20)); 
		System.out.println("print double"+cm.add(20.23, 30.0)); 
		 
	}

}
