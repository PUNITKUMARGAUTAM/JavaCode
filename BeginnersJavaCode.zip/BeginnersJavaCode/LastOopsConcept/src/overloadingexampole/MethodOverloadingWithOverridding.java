package overloadingexampole;

//class Parent {
//	
//	void dispay() {
//		System.out.println("Parent class");
//	}
//}
//
//
//class Child extends Parent{
//	
//	void display() {
//		System.out.println("Child class");
//	}
//	
//	void display(String str) {
//		System.out.println("Child class" + str);
//	}
//}
//
//
//public class MethodOverloadingWithOverridding {
//	
//	public static void main(String[] args) {
//		
//		Parent pn = new Parent();
//		Parent pc= new Child();
//        Child ch= new Child();
//        
//        
//		pn.dispay();
//		pc.dispay();
//		ch.dispay();
//		ch.display("Hello");
//	}
//
//}


class Parent {
    void display() {
        System.out.println("Parent class");
    }
}

class Child extends Parent {
    void display() {
        System.out.println("Child class");
    }
    
    void display(String str) {
        System.out.println("Child class: " + str);
    }
}

public class MethodOverloadingWithOverridding {
    public static void main(String[] args) {
        Parent obj1 = new Parent();
        Parent obj2 = new Child();
        Child obj3 = new Child();
        
        obj1.display();  // Output: Parent class
        obj2.display();  // Output: Child class
        obj3.display();  // Output: Child class
        obj3.display("Hello");  // Output: Child class: Hello
    }
}

