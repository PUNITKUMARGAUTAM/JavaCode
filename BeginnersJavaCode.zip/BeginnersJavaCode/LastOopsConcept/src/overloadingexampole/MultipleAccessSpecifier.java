package overloadingexampole;

public class MultipleAccessSpecifier {
	
	private void display(int num) {
		System.out.println("Print num of private=" + num);
	}
	
	public void display(String str) {
		System.out.println("Print the string value=" + str);
	}
	
	protected void display(float num3) {
		System.out.println("Print float number="+ num3);
	}
	
	public static void main(String[] args) {
		
		MultipleAccessSpecifier ma= new MultipleAccessSpecifier();
		
		ma.display(20);
		ma.display("ManMohan");
		ma.display(2.3f);
	}

}


// print null values
//class OverloadingDemo {
//    void display(String str) {
//        System.out.println("String: " + str);
//    }
//    
//    void display(Integer num) {
//        System.out.println("Integer: " + num);
//    }
//    
//    void display(Object obj) {
//        System.out.println("Object: " + obj);
//    }
//}
//
//public class MainClass1 {
//    public static void main(String[] args) {
//        OverloadingDemo obj = new OverloadingDemo();
//        obj.display("Hello");
//        obj.display(10);
//        obj.display(null);
//    }
//}