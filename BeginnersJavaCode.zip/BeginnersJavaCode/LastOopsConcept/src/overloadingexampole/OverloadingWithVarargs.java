package overloadingexampole;

public class OverloadingWithVarargs {
	
	public static void printNumbers(int... num) {
		System.out.println("Printing integers");
		
		for(int n: num) {
			System.out.println(" "+ n);
		}
		System.out.println();
	}
	
	public static void printNumbers(double... dl) {
		System.out.println("Printing double number");
		for(double dls: dl) {
			System.out.println(" " + dls);
		}
		
		System.out.println();
	}
	
	public static void printNumbers(String... str) {
		System.out.println("Printing string value");
		for(String st: str) {
			System.out.println(""+ st);
		}
		System.out.println();
	}
	
	public static void main(String[] args) {
		
		printNumbers(10,20,30,40);
		printNumbers(12.3,34.45,20.48);
		printNumbers("Rohit","Narendra","Manmohan","Rajat");
	}

}
