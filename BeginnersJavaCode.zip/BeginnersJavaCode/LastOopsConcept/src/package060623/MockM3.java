package package060623;



	public class MockM3 {
	    public static void main(String[] args) {
	        int x = 5;

	        if (x > 0) {
	            int y = 10;
	            System.out.println("x: " + x + ", y: " + y);
	        }

	        System.out.println("x: " + x + ", y: " + y);
	    }
	}

