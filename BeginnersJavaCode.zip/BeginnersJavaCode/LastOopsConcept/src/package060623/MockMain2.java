package package060623;

public class MockMain2 {
	
	 int number;

	    MockMain2(int number){
	        this.number = number;
	    }

	    public void func1(int number) {
	        number = this.number + number;
	        System.out.print(number);
	    }

	    public static void func2(int[] arraySample, int number) {
	        arraySample[0] = number / 2;
	    }

	    public static void main(String[] args) {
	        int number = 4;

	        int[] mainArray = new int[9];
	        mainArray[0] = 5;

	        MockMain2 object = new MockMain2(6);

	        object.func1(number);
	        System.out.print(" " + number);

	        func2(mainArray, object.number);
	        int i = 0;
	        while (i < mainArray.length && mainArray[i] != 0) {
	            System.out.print(" " + mainArray[i++]);
	        }
	    }

}
