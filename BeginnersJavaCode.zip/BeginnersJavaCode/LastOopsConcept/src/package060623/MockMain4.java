package package060623;

public class MockMain4 {
	
	  public static void main(String[] args) {
	        try {
	            int[] numbers = {1, 2, 3};
	            System.out.println(numbers[5]);
	        } catch (ArrayIndexOutOfBoundsException ex) {
	            System.out.print("Array index out of bounds! || ");
	            throw ex;
	        } catch (Exception ex) {
	            System.out.print("An exception occurred!");
	        }
	    }

}
