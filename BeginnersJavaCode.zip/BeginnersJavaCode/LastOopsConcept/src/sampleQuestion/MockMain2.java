package sampleQuestion;

public class MockMain2 {
	
	
	
	 public static void func1(int a){
	        a= a+1;
	        
	     
	        
	    }

	    public static void func2(int[] arraySample){
	        arraySample[0] = arraySample[0] / 2;
	    }

	    public static void main (String[] args){
	        int a =47;

	        int mainArray [] = new int[9];
	        mainArray[0] = 5;

	        func1(a);
	        System.out.print(a);

	        func2(mainArray);
	        int i = 0;
	        while (i<mainArray.length){
	            int temp = mainArray[i++];
	            if (temp!=0)
	                System.out.print(" " + temp);
	        }
	    }
	}  


