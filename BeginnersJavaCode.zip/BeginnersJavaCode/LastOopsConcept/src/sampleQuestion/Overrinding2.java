package sampleQuestion;

class Automobile1 {
    protected String drive() {
        return "Driving vehicle";
    }
}

class Car2 extends Automobile1 {
    private String drive() {
        return "Driving car";
    }
}

public class Overrinding2 extends Car2 {

    @Override
    public final String drive() {
        return "Driving electric car";
    }

    public static void main(String[] wheels) {
        final Car2 car = new Overrinding2();
        System.out.print(car.drive());
    }
}