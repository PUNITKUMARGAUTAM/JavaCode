package scopeofvariables;

public class OuterVariable {

	
	 public static void main(String[] args) {
	        int outerVariable = 10;

	        if (outerVariable == 10) {
	            int innerVariable = 20;
	            System.out.println("Inner Variable: " + innerVariable);
	            System.out.println("Outer Variable: " + outerVariable);
	        }

	        // The following line will result in a compilation error because the innerVariable is out of scope
	        // System.out.println("Inner Variable: " + innerVariable);

	        // The outerVariable is still in scope outside the if block
	        System.out.println("Outer Variable: " + outerVariable);
	    }
}
