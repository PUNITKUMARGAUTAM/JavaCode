package scopeofvariables;

public class ScopeExample {
    int x = 5;

    public void printValue() {
        int x = 10;
        System.out.println(x);  // Output: 10
    }
    
    public static void main(String[] args) {
        ScopeExample obj = new ScopeExample();
        obj.printValue();
    }
}