package scopeofvariables;

public class ScopeExampleForInnerClass {
	
	
	 public void outerMethod() {
	        int x = 5;

	        class InnerClass {
	            public void printValue() {
	                System.out.println(x);  // Output: 5 (accesses local variable of outerMethod())
	            }
	        }

	        InnerClass innerObj = new InnerClass();
	        innerObj.printValue();
	    }
	    
	    public static void main(String[] args) {
	    	ScopeExampleForInnerClass obj = new ScopeExampleForInnerClass();
	        obj.outerMethod();
	    }

}
