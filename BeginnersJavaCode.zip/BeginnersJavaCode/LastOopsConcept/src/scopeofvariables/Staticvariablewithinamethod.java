package scopeofvariables;

public class Staticvariablewithinamethod {
	
	static int x = 5;

    public void printValue() {
        int x = 10;
        System.out.println(Staticvariablewithinamethod.x);  // Output: 5 (accesses static variable)
    }
    
    public static void main(String[] args) {
    	Staticvariablewithinamethod obj = new Staticvariablewithinamethod();
        obj.printValue();
    }

}
