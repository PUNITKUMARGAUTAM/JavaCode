package JavaInterviewQuestion180323;


// Print integer java start
public class BeginingClass {
	
	public static void main(String[] args) {
	
//	int i;
//	for(i=1; i<=10; i++) {
//		System.out.println(1);
//		
//	}
	// end
	
	// command line arguments in java
	
	for(String t: args) {
		System.out.println(t);

}
}
}
