package JavaInterviewQuestion180323;

import java.util.Scanner;

public class ConverFahrenheittoCelsius {

	public static void main(String[] args) {
		float temperature;
		Scanner in= new Scanner(System.in);
		
		System.out.println("Enter temprature in Fahrenheit");
		temperature=in.nextInt();
		
		temperature = ((temperature=32)*5)/9;
		System.out.println("Temprature in Celcius = "+temperature);
		

	}

}
