package JavaInterviewQuestion180323;

import java.util.Scanner;

public class GetInputFromUser {
	
	public static void main(String args[]) {
		
		int a;
		float b;
		String s;
		
		Scanner in= new Scanner(System.in);
		
		System.out.println("Enter an Integer ");
		a= in.nextInt();
		System.out.println("You entered Integer"+a);
		
		System.out.println("Enter an String ");
		s=in.nextLine();
//		System.out.println(s);
		System.out.println("You entered an String"+s);
		
		System.out.println("Enter an float Number");
		b=in.nextFloat();
		System.out.println("You entered a float Number"+b);
	
	}

}
