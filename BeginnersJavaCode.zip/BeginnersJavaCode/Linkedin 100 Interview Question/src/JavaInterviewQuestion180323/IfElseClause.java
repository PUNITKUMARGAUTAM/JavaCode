package JavaInterviewQuestion180323;

public class IfElseClause {

	public static void main(String[] args) {
		
		boolean learning = true;
		
		if(learning ) {
			System.out.println("Java programmer");
		}
		else {
			System.out.println("What are you doing here");
		}
	}
}
