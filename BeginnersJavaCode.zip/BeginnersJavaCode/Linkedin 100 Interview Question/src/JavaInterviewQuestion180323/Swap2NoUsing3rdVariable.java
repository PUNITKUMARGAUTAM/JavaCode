package JavaInterviewQuestion180323;

import java.util.Scanner;

public class Swap2NoUsing3rdVariable {

	public static void main(String[] args) {
		
		int x,y, temp;
		System.out.println("Enter x and y Number");
		Scanner sc= new Scanner(System.in);
		
		x=sc.nextInt();
		y=sc.nextInt();
		
		System.out.println("Before Swapping\nx = "+x+"\ny="+y);
		
		temp=x;
		x=y;
		y=temp;
		
		System.out.println("After Swapping\nx = "+x+"\ny="+y);
		

	}

}
