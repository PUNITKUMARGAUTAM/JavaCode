package JavaInterviewQuestion180323;

import java.util.Scanner;

public class Swap2NoWithoutUsing3rdVariable {
	
	public static void main(String args[]) {
		
		int x,y;
		System.out.println("Enter x and y number");
		
		Scanner sc= new Scanner(System.in);
		
		x=sc.nextInt();
		y=sc.nextInt();
		
		System.out.println("Before swapping \nx= "+x+" \ny="+y);
		
		x=y;
		y=x;
		
		System.out.println("After swapping \nx= "+x+" \ny="+y);
	}
}
