package JavaInterviewQuestion190323NoStart11;

//public class EnhanceLoop {
//	
//	public static void main(String[] args) {
//		
//		int primes[] = {2,3,7,9,11,13,17,19,21,27,31};
//		
//		for( int t : primes) {
//			System.out.println(t);
//		}
//	}
//
//}


//For String
class EnhanceLoop {
public static void main(String[] args) {
String languages[] = { "C", "C++", "Java", "Python", "Ruby"};
for (String sample: languages) {
System.out.println(sample); } } }