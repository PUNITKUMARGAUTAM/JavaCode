package JavaInterviewQuestion190323NoStart11;

import java.util.Scanner;

public class FactorialNumber {
	
	public static void main(String[] args) {
		
		int n,c,fact=1;
		
		System.out.println("Enter number and check factorial number");
		
		Scanner sc= new Scanner(System.in);
		
		n=sc.nextInt();
		
		if( n < 0) {
			System.out.println("Number should be no zero");
		}
		
		else {
			for(c=1; c <= n; c++) {
				fact = fact*c;
			System.out.println("Factorial of "+ n +" is = "+fact);		}
			
	}
	}
}

//class FactorialExample2{  
//	 static int factorial(int n){    
//	  if (n == 0)    
//	    return 1;    
//	  else    
//	    return(n * factorial(n-1));    
//	 }    
//	 public static void main(String args[]){  
//	  int i,fact=1;  
//	  int number=5;//It is the number to calculate factorial    
//	  fact = factorial(number);   
//	  System.out.println("Factorial of "+number+" is: "+fact);    
//	 }  
//	}  


//class FactorialExample{  
//	 public static void main(String args[]){  
//	  int i,fact=1;  
//	  int number=5;//It is the number to calculate factorial    
//	  for(i=1;i<=number;i++){    
//	      fact=fact*i;    
//	  }    
//	  System.out.println("Factorial of "+number+" is: "+fact);    
//	 }  
//	}  