package JavaInterviewQuestion190323NoStart11;

import java.util.Scanner;

public class IfElseClausePassedorFailed {

	public static void main(String[] args) {
		
		int passedMarks, obtainedMark;
		
		passedMarks=40;
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Input marks scord by you");
		obtainedMark=sc.nextInt();
		
		if(obtainedMark >= passedMarks) {
			
			System.out.println("Congratulations you are qualify your exam");
			
		}
		
		else {
			System.out.println("Unfortunaltly you are qualify your exam, please try next year best of luck");
		}
		
	}
}
