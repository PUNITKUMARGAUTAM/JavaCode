package JavaInterviewQuestion190323NoStart11;

import java.util.Scanner;

public class NestedIf {
	
	public static void main(String[] args) {
		
		int markObtained , passingMarks;
		
		char grade;
		
		passingMarks=40;
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter yor scored marks");
		
		markObtained=sc.nextInt();
		
		if(markObtained >= passingMarks) {
			if(markObtained > 90) {
				grade = 'A';
			}
		}
	}

}
