package JavaInterviewQuestion190323NoStart11;

import java.util.Scanner;

public class OddEvenNumber {
	
	public static void main(String[] args) {
		
		int x;
		
		System.out.println("Enter number and check even or odd");
		
		Scanner in= new Scanner(System.in);
		
		x=in.nextInt();
		
		if(x%2==0) {
			System.out.println("Number which is you entered even number");
		}
		else {
			System.out.println("Number which is you entered odd number");
		}
			
	}

}
