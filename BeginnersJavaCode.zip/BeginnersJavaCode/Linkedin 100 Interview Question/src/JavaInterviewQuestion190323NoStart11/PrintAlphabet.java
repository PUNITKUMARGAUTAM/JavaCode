package JavaInterviewQuestion190323NoStart11;

public class PrintAlphabet {
	
	public static void main(String[] args) {
		
		char ch ;
		
		
//		for(ch=65; ch <= 90 ; ch++) {
			for(ch='A'; ch<='Z'; ch++) {
				
			System.out.println( ch +"="+ (int)ch  );
		}
	}

}
