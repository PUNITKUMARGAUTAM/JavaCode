package JavaInterviewQuestion190323NoStart11;

public class PrintStar {
	
	public static void main(String[] args) {
		
		int row, numberOfStar;
		
		for(row=1; row<=10; row++) {
			for(numberOfStar=1; numberOfStar <= row; numberOfStar++) {
				System.out.print("*");
			}
			System.out.println();
			
		}
	}

}
