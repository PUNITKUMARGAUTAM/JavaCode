package JavaInterviewQuestion190323NoStart11;

import java.util.Scanner;

public class ReverseNumber {
	
	public static void main(String[] args) {
		
		int n,reverse=0;
		
		System.out.println("Enter the number to Reverse ");
		Scanner in= new Scanner(System.in);
		
		n=in.nextInt();
		
		while(n !=0) {
			
			reverse= reverse*10;
			
			reverse= reverse + n%10;
			
			n= n/10;
			
		
			
			
			
		}
		System.out.println("Reverse number is "+ reverse);
	}

}
