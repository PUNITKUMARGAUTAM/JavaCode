package JavaInterviewQuestion190323NoStart11;

import java.util.Scanner;

public class TableOfMultiplication {

	public static void main(String[] args) {
		
//		int a;
//		for(a=1; a<=10; a++) {
//			
//			System.out.println(2*a); // 2,4,6,8,10,12,14,16,18,20
//			
//		}
//		

//		int n, c;
//		
//		System.out.println("Enter an integer to print it's multiplication table");
//		
//		Scanner in = new Scanner(System.in); 
//		n = in.nextInt();
//		
//		System.out.println("Multiplication table of "+n+" is :-");
//		
//		for ( c = 1 ; c <= 10 ; c++ )
//			
//		System.out.println(n+"*"+c+" = "+(n*c)); 
		
		///////// FOR ANY NUMBER ///////////////
		
		int a, b, c, d;
		class MultiplicationTable
		{
		public static void main(String args[])
		{
		int n, c;
		
		System.out.println("Enter an integer to print it's multiplicationtable");
		
		Scanner in = new Scanner(System.in); 
		
		n = in.nextInt();
		
		System.out.println("Multiplication table of "+n+" is :-");
		
		for ( c = 1 ; c <= 10 ; c++ )
		
		System.out.println(n+"*"+c+" = "+(n*c)); 
		}
		}
		
		System.out.println("Enter range of numbers to print their multiplicationtable");
		
		Scanner in = new Scanner(System.in);
		
		a = in.nextInt(); 
		
		b = in.nextInt();
		
		for (c = a; c <= b; c++) {
		
		System.out.println("Multiplication table of "+c);
		
		for (d = 1; d <= 10; d++) {
		
		System.out.println(c+"*"+d+" = "+(c*d)); } } 
	}

}


//output==> Enter range of numbers to print their multiplicationtable
//2
//6
//Multiplication table of 2
//2*1 = 2
//2*2 = 4
//2*3 = 6
//2*4 = 8
//2*5 = 10
//2*6 = 12
//2*7 = 14
//2*8 = 16
//2*9 = 18
//2*10 = 20
//Multiplication table of 3
//3*1 = 3
//3*2 = 6
//3*3 = 9
//3*4 = 12
//3*5 = 15
//3*6 = 18
//3*7 = 21
//3*8 = 24
//3*9 = 27
//3*10 = 30
//Multiplication table of 4
//4*1 = 4
//4*2 = 8
//4*3 = 12
//4*4 = 16
//4*5 = 20
//4*6 = 24
//4*7 = 28
//4*8 = 32
//4*9 = 36
//4*10 = 40
//Multiplication table of 5
//5*1 = 5
//5*2 = 10
//5*3 = 15
//5*4 = 20
//5*5 = 25
//5*6 = 30
//5*7 = 35
//5*8 = 40
//5*9 = 45
//5*10 = 50
//Multiplication table of 6
//6*1 = 6
//6*2 = 12
//6*3 = 18
//6*4 = 24
//6*5 = 30
//6*6 = 36
//6*7 = 42
//6*8 = 48
//6*9 = 54
//6*10 = 60

