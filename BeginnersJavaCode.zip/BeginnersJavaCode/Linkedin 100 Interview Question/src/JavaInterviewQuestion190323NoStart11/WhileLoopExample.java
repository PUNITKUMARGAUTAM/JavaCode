package JavaInterviewQuestion190323NoStart11;

import java.util.Scanner;

public class WhileLoopExample {
	
	public static void main(String[] args) {
		
		int n;
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter input as integer ");
		
		while((n = input.nextInt()) !=0) {
			System.out.println("You Entered " + n);
			
			System.out.println("Input an integer");
		}
		
		System.out.println("Out of loop");
	}

}
