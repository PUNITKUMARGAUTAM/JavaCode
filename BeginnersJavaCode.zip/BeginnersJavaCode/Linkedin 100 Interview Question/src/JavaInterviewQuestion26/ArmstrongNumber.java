package JavaInterviewQuestion26;
//
//import java.util.Scanner;
//
////public class ArmstrongNumber {
////	
////	public static void main(String[] args) {
////		
////		int n,sum=0, temp,remainder, digits=0;
////		
////		Scanner in = new Scanner(System.in);
////		
////		System.out.println("Input a number to check if it is a Armstrong number");
////		
////		n=in.nextInt();
////		
////		temp = n;
////		
////		// count number of digits
////		
////		while(temp !=0) {
////			digits++;
////			temp = temp/10;
////			
////		}
////		
////		temp = n;
////		
////		while(temp !=0 ) {
////			remainder = temp%10;
////			
////			sum= sum + power(remainder,digits);
////		}
////		
////		if(n== sum) {
////			System.out.println(n + "is an Armstrong number");
////		}
////		
////		else {
////			System.out.println(n + "is not Armstrong number");
////		}
////	}
////		
////		static int power (int n, int r) {
////			
////			int c, p=1;
////					
////					for(c=1; c<=r; c++) {
////						p=p*n;
////						
////						
////					}
////					return p;
////		
////	}
////
////}
//
//
//import java.util.Scanner;
//class ArmstrongNumber
//{
//public static void main(String args[])
//{
//int n, sum = 0, temp, remainder, digits = 0;
//Scanner in = new Scanner(System.in);
//System.out.println("Input a number to check if it is an Armstrong number");
//n = in.nextInt();
//temp = n;
//// Count number of digits
//while (temp != 0) {
//digits++;
//temp = temp/10; }
//temp = n;
//while (temp != 0) {
//remainder = temp%10;
//sum = sum + power(remainder, digits);
//temp = temp/10; }
//if (n == sum)
//System.out.println(n + " is an Armstrong number.");
//System.out.println(n + " is not an Armstrong number.");
//static int power(int n, int r) {
//int c, p = 1;
//for (c = 1; c <= r; c++) p = p*n;
//return p;
//}
//}
//

import java.util.Scanner;  
import java.lang.Math;  
public class ArmstrongNumber  
{  
//function to check if the number is Armstrong or not  
static boolean isArmstrong(int n)   
{   
int temp, digits=0, last=0, sum=0;   
//assigning n into a temp variable  
temp=n;   
//loop execute until the condition becomes false  
while(temp>0)    
{   
temp = temp/10;   
digits++;   
}   
temp = n;   
while(temp>0)   
{   
//determines the last digit from the number      
last = temp % 10;   
//calculates the power of a number up to digit times and add the resultant to the sum variable  
sum +=  (Math.pow(last, digits));   
//removes the last digit   
temp = temp/10;   
}  
//compares the sum with n  
if(n==sum)   
//returns if sum and n are equal  
return true;      
//returns false if sum and n are not equal  
else return false;   
}   
//driver code  
public static void main(String args[])     
{     
int num;   
Scanner sc= new Scanner(System.in);  
System.out.print("Enter the limit: ");  
//reads the limit from the user  
num=sc.nextInt();  
System.out.println("Armstrong Number up to "+ num + " are: ");  
for(int i=0; i<=num; i++)  
//function calling  
if(isArmstrong(i))  
//prints the armstrong numbers  
System.out.print(i+ ", ");  
}   
}  
