package JavaInterviewQuestion26;

import java.util.Scanner;

//public class PrimeNumberCheck {
//	
//	public static void main(String[] args) {
		
		
//		int n, status=1, num=3;
//		
//		Scanner sc= new Scanner(System.in);
//		
//		System.out.println("Enter the number of prime numbers you want"); 
//		
//		n = sc.nextInt();
//		
//		if (n >= 1) {
//			System.out.println("First "+n+" prime numbers are :-");
//			System.out.println(2); }
//		
//		for( int count=2; count<=n; ) {
//			for(int j=2; j<= Math.sqrt(num); j++) {
//				
//				if(num%2==0) {
//					status=0;
//					break;
//				}
//				
//				if(status !=0 ) {
//					System.out.println(num);
//					count++;
//				}
//			}
//		}
//	}
//
//}
     public class PrimeNumberCheck {
		   public static void main(String[] args) {
		       Scanner scanner = new Scanner(System.in);
		       System.out.print("Enter a number: ");
		       int number = scanner.nextInt();
		       scanner.close();
		       
		       boolean isPrime = true;
		       
		       if (number <= 1) {
		           isPrime = false;
		       } else {
		           for (int i = 2; i <= Math.sqrt(number); i++) {
		               if (number % i == 0) {
		                   isPrime = false;
		                   break;
		               }
		           }
		       }
		       
		       if (isPrime) {
		           System.out.println(number + " is a prime number.");
		       } else {
		           System.out.println(number + " is not a prime number.");
		       }
		   }
		}

