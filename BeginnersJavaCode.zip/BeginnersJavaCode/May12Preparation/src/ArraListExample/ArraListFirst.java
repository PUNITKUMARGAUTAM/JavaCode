package ArraListExample;

import java.util.ArrayList;
import java.util.Iterator;

//Iterate ArrayList using Iterator 
public class ArraListFirst {
	
	public static void main(String[] args) {
		
		ArrayList<String> al= new ArrayList<String>();
		
		al.add("Pathak");
		al.add("Raju");
		al.add("Kavita");
		
//		Iterator itr=al.iterator();
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}
	
	// traverse the elements using for loop
		
		for(String m: al) {
			System.out.println(m);
		}
	
	}

	
	
}
