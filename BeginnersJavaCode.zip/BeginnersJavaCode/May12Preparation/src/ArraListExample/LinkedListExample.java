package ArraListExample;

import java.util.LinkedList;

public class LinkedListExample {
	
//	public static void main(String[] args) {
//		
//		LinkedList<String> al= new LinkedList<String>();
//		
//		System.out.println("Initial list of elements = " + al);
//		al.add("Ravi");
//		al.add("Rahul");
//		al.add("Vijay");
//		al.add("Jayant");
//		System.out.println("After add elements = " + al);
//		al.add(1,"Gaurav");
//		System.out.println("After add element based on index = " + al);
//		
//		LinkedList<String> al1= new LinkedList<String>();
//		al1.add("Mohan");
//		al1.add("Rajat");
//		al.addAll(al1);
//		System.out.println("After invoking addAll method : " + al);
//		
//		LinkedList<String> al2= new LinkedList<String>();
//		al2.add("John");
//		al2.add("Raja");
//		al1.addAll(1,al2);
//		System.out.println("After invoking addAll: " +al1);
//		
//		al1.addFirst("Lokesh");
//		System.out.println("After invoking addFirst method" + al1);
//		al1.addLast("Harsh");
//		System.out.println("After invoking addLast method "+ al1);
		
		
	public static void main(String[] args) {
		
		LinkedList<String> lt= new LinkedList<String>(); 
		lt.add("Raju");
		lt.add("Ramesh");
		lt.add("Niharika");
		System.out.println("After add element " + lt);
		lt.add(1,"Mohit");
		lt.add(2,"NewName");
		System.out.println("After add element of index based" + lt);
		
		LinkedList<String> al= new LinkedList<String>();
		al.add("Sonoo");
		al.add("Hanumat");
		lt.addAll(al);
		
		System.out.println("After invoking addAll method:" + al);
		
		LinkedList<String> al2= new LinkedList<String>();
		
		al2.add("John");
		al2.add("Rahul");
		al.addAll(1,al2);
		
		System.out.println("After invoking addAll method of al2 :" + al);
		
		al.addFirst("Lokesh");
		System.out.println("After invoking addFirst method of al2 :" +al);
		
		al2.addLast("Harsh");
		System.out.println("After invoking addLast method of al2 :" +al2);
		
		
	}

}
