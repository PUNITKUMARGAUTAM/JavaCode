package ArraListExample;

import java.util.Iterator;
import java.util.LinkedList;

public class ReverseLinkedList {
	
	public static void main(String[] args) {
		
		LinkedList<String> al= new LinkedList<String>();
		al.add("Ajeet");
		al.add("Roshan");
		al.add("Janak");
		
		Iterator itr=al.descendingIterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}

}
