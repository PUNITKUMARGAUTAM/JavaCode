package ArraListExample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortArrayList {
	
	public static void main(String[] args) {
		
//		ArrayList<String> al= new ArrayList<String>();
//		
//		al.add("Ram");
//		al.add("Bhim");
//		al.add("Rohit");
//		al.add("Amarjeet");
//		
//		System.out.println("Sorting String");
//		
//		Collections.sort(al);
//		for(String m:al) {
//			System.out.println(m);
//		}
//		
//		System.out.println("Sorting number");
//		List<Integer> num= new ArrayList<Integer>();
//		num.add(12);
//		num.add(15);
//		num.add(75);
//		Collections.sort(num);
//		for(Integer hm:num) {
//			System.out.println(hm);
//		}
		
		
		ArrayList<String> ls= new ArrayList<String>();
		ls.add("Manmohan");
		ls.add("Baju");
		ls.add("Rohit");
		ls.add("Aman");
		
		Collections.sort(ls);
		for(String sm:ls) {
			System.out.println(sm);
		}
		
		System.out.println("Sorting number=");
		
		List<Integer> num= new ArrayList<Integer>();
		num.add(12);
		num.add(13);
		num.add(34);
		num.add(18);
		num.add(22);
		
		Collections.sort(num);
		for(Integer hm:num) {
			System.out.println(hm);
			
		}
		
	}

}
