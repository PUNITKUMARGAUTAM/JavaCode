package CollectionImp;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class IterareElementInList {
	
//	public static void main(String[] args) {
//		
//		List<String> list= new ArrayList<String>();
//		
//		list.add("Aman");
//		list.add("Rajat");
//		list.add("Sonu");
//		list.add("Sahil");
//		
//		ListIterator<String> itr= list.listIterator();
//		System.out.println("Traversing element in forward direction=> ");
//		
//		while(itr.hasNext()) {
//			System.out.println("index" + itr.nextIndex() + " value= " + itr.next());
//		}
//		
//		
//		
//		System.out.println("Traversing element in backword direction");
//		
//		while(itr.hasPrevious()) {
//			System.out.println("index" + itr.previousIndex() + " Value= " + itr.previous());
//		}
//		
//	}

	
	public static void main(String[] args) {
		
		List<String> list= new ArrayList<String>(); 
		list.add("Raju");
		list.add("Mohit");
		list.add("Amit");
		list.add("Zebra");
		
		ListIterator<String> itr= list.listIterator();
		System.out.println("Traversing element in forward direction");
		
		while(itr.hasNext()) {
			System.out.println("index=" + itr.nextIndex()+ "Value=" + itr.next());
		}
		
		System.out.println("Traversing element in backword direction");
		
		while(itr.hasPrevious()) {
			System.out.println("index=" + itr.previousIndex() + "value="+ itr.previous()) ;
		}
	}
}
