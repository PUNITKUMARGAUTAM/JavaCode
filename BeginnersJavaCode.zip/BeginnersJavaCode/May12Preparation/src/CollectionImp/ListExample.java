package CollectionImp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListExample {
	
	public static void main(String[] args) {
		
		List<String> list= new ArrayList<String>();
		
		list.add("Rohit");
		list.add("Rahul");
		list.add("Aman");
		
//		Collections.sort(list);
//		System.out.println(list);
		
		System.out.println("Returning element: " + list.get(2));
		list.add(3,"Manjit");
		
		System.out.println("After returming element ");
		for(String str: list) {
			System.out.println(str);
		}
	}

}
