package DataStructureExample;

import java.util.Scanner;

public class ArrayInserSpscificPositionElement {
	
	public static void main(String[] args) {
		
//		int[] arr= new int[5];
//		System.out.println("Enter the element");
//		
//		Scanner sc= new Scanner(System.in);
//		for(int i=0; i<arr.length-1; i++) {
//			arr[i]=sc.nextInt();
//		}
//		System.out.println("Printing element before insert");
//		for(int i: arr) {
//			System.out.println(i);
//		}
//		
//		System.out.println("Enter the location which we want to insert");
//		int location=sc.nextInt();
//		System.out.println("Enter the value which we want to insert");
//		int value=sc.nextInt();
//		
//		for(int i=arr.length-1; i>location; i--) {
//			arr[i]=arr[i-1];
//		}
//		arr[location]=value;
//		for(int i: arr) {
//			System.out.println(arr);
//		}
		
		 int n, pos, x;
	        Scanner s = new Scanner(System.in);
	        System.out.print("Enter no. of elements you want in array:");
	        n = s.nextInt();
	        int a[] = new int[n+1];
	        System.out.println("Enter all the elements:");
	        for(int i = 0; i < n; i++)
	        {
	            a[i] = s.nextInt();
	        }
	        System.out.print("Enter the position where you want to insert element:");
	        pos = s.nextInt();
	        System.out.print("Enter the element you want to insert:");
	        x = s.nextInt();
	        for(int i = (n-1); i >= (pos-1); i--)
	        {
	            a[i+1] = a[i];
	        }
	        a[pos-1] = x;
	        System.out.print("After inserting:");
	        for(int i = 0; i < n; i++)
	        {
	            System.out.print(a[i]+",");
	        }
	        System.out.print(a[n]);
	    }
	}


