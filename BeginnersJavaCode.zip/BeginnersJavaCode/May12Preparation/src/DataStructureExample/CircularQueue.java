package DataStructureExample;

public interface CircularQueue<T> {

	void enqueue(int i);

	String dequeue();

}
