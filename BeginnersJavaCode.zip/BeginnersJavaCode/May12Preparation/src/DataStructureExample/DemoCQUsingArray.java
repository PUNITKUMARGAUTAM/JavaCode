package DataStructureExample;


class CQoperation {
	
	int size=5;
	int rear=-1, front=-1, data;
	int[] CQ= new int[size];
	
	void insert(int data) {
		if(front == (rear+1%size)) {
			System.out.println("CQ is Full");
			return;
		}
		
		else 
		{
			rear=(rear+1)%size;
			CQ[rear]=data;
			if(front == -1) {
				front=(front+1)%size;
			}
			
			System.out.println("Data is inserted " + data);
		}
	}
	
	void delete() {
		if(front == -1 && rear == -1) {
			System.out.println("CQ is empty");
			return;
		}
		
		else {
			data = CQ [front];
			if(front == rear) {
				front = rear=-1;
				
			}
			
			front = (front+1)%size;
			System.out.println("Data is deleted " + data);
		}
	}
	void display() {
		if(front ==-1 && rear == -1) {
			System.out.println("CQ is empty");
			return;
		}
		else
		{
			int i;
			System.out.println("CQ is ");
			
			for(i=front; i!=rear; i=(i+1%size)) {
				System.out.println(CQ[i]);
				
			}
			System.out.println(CQ[i]);
		}
	}
}

public class DemoCQUsingArray {
	
	public static void main(String[] args) {
		
		CQoperation op= new CQoperation();
		op.insert(34);
		op.insert(36);
		op.insert(98);
		op.insert(67);
		op.insert(24);
//		op.insert(54);
		
		op.display();
		op.delete();
		op.display();
	}

}
