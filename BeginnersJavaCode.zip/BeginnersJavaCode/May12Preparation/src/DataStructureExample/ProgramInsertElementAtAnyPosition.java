package DataStructureExample;

import java.util.Scanner;

public class ProgramInsertElementAtAnyPosition {
	
	public static void main(String[] args) {
		
	
	
	int n, pos,x;
	
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the nu of array which you want ");
	n=sc.nextInt();
	int a[]= new int[n+1];
	System.out.println("Enter all the lements");
	for(int i=0; i <n; i++) {
		
		a[i]=sc.nextInt();
		System.out.println("Enter the position where you want insert the element");
		pos=sc.nextInt();
		System.out.println("Enter the elemnts you want to insert" );
		x=sc.nextInt();
		for(int i= (n-1); i >=(pos-1); i--) {
			a[i+1]=a[i];
			
			a[pos-1]=x;
			System.out.println("After inserting");
			for(int i=0; i <n; i++) {
				System.out.println(a[i]);
			}
			System.out.println(a[n]);
		}
		
	}
	
}
}
