package DataStructureExample;

public class QueueExampleFirst {
	
	int rear=-1, front=-1;
	int size=5;
	int arr[]=new int[size];
	
	public void enqueue(int data) {
		if(rear==size-1) {
			System.out.println("Overflow");
		}
		else {
			if(rear==-1 && front==-1) {
				rear++;
				front++;
				arr[rear]=data;
			}
			else
				rear++;
			arr[rear]=data;
		}
	}
	
	public void dequeue() {
		if(rear==-1 && front==-1) {
			System.out.println("empty");
		}
		else {
			for(int i=0; i<rear; i++) {
				arr[i]=arr[i+1];
			}
			rear--;
		}
	}
	
	public void display() {
		
		if(rear==-1 && front==-1) {
			System.out.println("empty");
		}
			for(int i=0; i<=rear; i++) {
				System.out.println(arr[i]);
				
			}
	}
	public void peek() {
		System.out.println(arr[front]);
			
			}
	
	public static void main(String[] args) {
		
		QueueExampleFirst qc= new QueueExampleFirst();
		qc.enqueue(10);
		qc.enqueue(20);
		qc.enqueue(30);
		qc.enqueue(40);
		qc.enqueue(50);
		qc.enqueue(60);
		
		qc.display();
		System.out.println("***********");
		qc.dequeue();
		qc.peek();
		qc.display();
		System.out.println("***********");
		qc.dequeue();
		qc.peek();
		qc.display();
		System.out.println("***********");
		qc.dequeue();
		qc.peek();
	}
		
	}
	


