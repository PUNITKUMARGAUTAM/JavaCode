package DataStructureExample;

public class QueueUsingArrayPractice {
	
	int front=-1,rear=-1;
	int size=5;
	int arr[]= new int[size];
	
	public void enqueue(int data) {
		if(rear==(size-1)) {
			System.out.println("Overflow");
			
		}
		
		else {
			if(rear==-1 && front==-1) {
				rear++;
				front++;
				arr[rear]=data;
			}
			else {
				rear++;
				arr[rear]=data;
			}
		}
		
	}
	
	public void dequeue() {
		if(rear==-1 && front==-1) {
			System.out.println("Empty");
		}
		else {
		for(int i=0; i<rear; i++) {
			arr[i]=arr[i+1];
		}
		rear--;
	}
	}	
		public void display() {
			if(rear==-1 && front==-1) {
				System.out.println("empty");
			}
			
			for(int i=0; i<=rear; i++) {
				System.out.println(arr[i]);
			}
		
	}

		public void peek() {
	   System.out.println(arr[front]);
			}
		 public static void main(String[] args) {
				
			 QueueUsingArray qq= new QueueUsingArray();
			 
			 qq.enqueue(10);
			 qq.enqueue(20);
			 qq.enqueue(30);
			 qq.enqueue(40);
			 qq.enqueue(50);
			 
			 qq.display();
			 System.out.println("***************");
			 qq.dequeue();
			 qq.display();
			 System.out.println("Peek value of queque");
			 qq.peek();
			 System.out.println("***************");
			 qq.dequeue();
			 qq.display();
			 System.out.println("Peek value of queque");
			 qq.peek();
			 System.out.println("***************");
			 qq.dequeue();
			 qq.display();
			 System.out.println("Peek value of queque");
			 qq.peek();
			
		}

}

