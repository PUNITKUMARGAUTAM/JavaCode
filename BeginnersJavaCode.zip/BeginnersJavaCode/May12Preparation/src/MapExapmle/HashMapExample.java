package MapExapmle;

import java.util.HashMap;
import java.util.Map;

public class HashMapExample {
	
	public static void main(String[] args) {
		
	
	
	HashMap <Integer , String> hm = new HashMap<Integer, String>();
	
	hm.put(100,"Amit");
	hm.put(101, "Vijay");
	hm.put(103, "Rahul");
	
	System.out.println("After invoking put() method");
	
	for(Map.Entry m: hm.entrySet()) {
		System.out.println(m.getKey() + "=" + m.getValue());
		
	}
	
	hm.putIfAbsent(104, "Gaurav");
	System.out.println("After invoking putIfAbsent method");
	
	for(Map.Entry ab: hm.entrySet()) {
		System.out.println(ab.getKey() + "=" + ab.getValue());
	}
	
	HashMap<Integer,String> hsm = new HashMap<Integer, String>();
	hsm.put(105,"Ajeet");
	hsm.putAll(hm);
	
	System.out.println("After invoking putAll() method");
	
	for(Map.Entry sm:hsm.entrySet()) {
		System.out.println(sm.getKey()+ " " + sm.getValue());
	}

}
}
