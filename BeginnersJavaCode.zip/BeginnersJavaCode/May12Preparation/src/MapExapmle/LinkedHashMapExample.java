package MapExapmle;

import java.util.LinkedHashMap;

public class LinkedHashMapExample {
	public static void main(String[] args) {
		
		LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
		
		map.put(101, "Punit");
		map.put(102, "Rohit");
		map.put(103, "Rajan");
		map.put(104, "Suri");
		
		System.out.println("keys " + map.keySet());
		map.remove(104);
		System.out.println("values" + map.values());
		
		System.out.println("Key-values-pairs" + map.entrySet());
	}

}
