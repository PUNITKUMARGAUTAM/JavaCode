package MapExapmle;

import java.util.HashMap;
import java.util.Map;

public class MapFirst {
	
	public static void main(String[] args) {
		
		Map<Integer,String> map= new HashMap<Integer,String>();
		
		map.put(1,"Ajeet");
		map.put(2,"Pallavi");
		map.put(3,"Rohit");
		
		for(Map.Entry m: map.entrySet()) {
			
			System.out.println(m.getKey() + "=" + m.getValue());
		}
		
	}

}
