package PassByValueAndPassByReference;


class Car{
	
	String name;
	int cost;
	float milage;
}
public class PassBYRefernceExapmple {
	
	public static void main(String[] args) {
		
	
	
	Car a = new Car();
	a.name="BMW";
	a.cost=12300;
	a.milage=120;
	
	System.out.println(a.name);
	System.out.println(a.cost);
	System.out.println(a.milage);
	
	Car b;
	b=a;
	System.out.println(b.name);
	System.out.println(b.cost);
	System.out.println(b.milage);
	
	b.name="TATA";
	b.cost=75000;
	b.milage=150;
	
	System.out.println(b.name);
	System.out.println(b.cost);
	System.out.println(b.milage);
	
	System.out.println(a.name);
	System.out.println(a.cost);
	System.out.println(a.milage);
	
	
	

}
}