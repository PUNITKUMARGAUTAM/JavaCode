package ScopeOfVariables;

public class BlocScopeExample {
	
//	public static void main(String[] args) {
//		
//		int x;
//		for(x=0; x<10; x++) {
//			System.out.println(x + "\t");
//	}
//		System.out.println(x);

//}
	
	
	public static void main(String[] args) {
		
		int x;
		for(x=0; x<10; x++) {
			System.out.println(x + "\t");
			
		}
		System.out.println(x);
	}
}
