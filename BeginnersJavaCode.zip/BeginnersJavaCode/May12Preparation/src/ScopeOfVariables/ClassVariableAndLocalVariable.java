package ScopeOfVariables;

public class ClassVariableAndLocalVariable {
	
	private int a;
	
	public void setNumber(int a) {
		this.a=a;
		System.out.println("The value of a is:"+a);
	}
	
	public static void main(String[] args) {
		
		ClassVariableAndLocalVariable dc= new ClassVariableAndLocalVariable();	
	    dc.setNumber(5);	
	}
	

}
