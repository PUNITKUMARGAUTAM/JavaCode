package ScopeOfVariables;

public class EmpClassScope {
	
	public String name;
	private double salary;
	
	public EmpClassScope(String empName) {
		name=empName;
	}
	
	public void setSalary(double empSalary) {
		salary=empSalary;
	}
	
	public void printInfo() {
		System.out.println("Name of emp :"+name);
		System.out.println("Salary of emp :" + salary);
	}
	
	public static void main(String[] args) {
		
		EmpClassScope sc= new EmpClassScope("Rohit");
		sc.setSalary(2000);
		sc.printInfo();
	}

}
