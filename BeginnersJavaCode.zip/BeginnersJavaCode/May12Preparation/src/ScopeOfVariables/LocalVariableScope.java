package ScopeOfVariables;

public class LocalVariableScope {
	
//   void show() {
//	   
//	   int x=10;
//	   
//	   System.out.println("The vlaue of x:"+x);
//   }
//   
//   public static void main(String[] args) {
//	
//	   LocalVariableScope ls= new LocalVariableScope();
//	   ls.show();
//}
	
	void show() {
		int x=10;
		
		System.out.println("The value of x= "+ x);
		
	}
	
	public static void main(String[] args) {
		
		LocalVariableScope ls= new  LocalVariableScope();
		ls.show();
	}
}
