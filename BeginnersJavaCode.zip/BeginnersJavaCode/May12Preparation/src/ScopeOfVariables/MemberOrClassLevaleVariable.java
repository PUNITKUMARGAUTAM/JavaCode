package ScopeOfVariables;

public class MemberOrClassLevaleVariable {
	
//	public String name;
//	private double salary;
//	
//	public MemberOrClassLevaleVariable (String empName) {
//	
//	name= empName;
//	}
//	
//	public void setSlary(double empSalary) {
//		salary= empSalary;
//	}
//	
//	public void printInfo() {
//		System.out.println("Name of emp :" + name);
//		System.out.println("Salary of emp:" + salary);
//	}
//	
//	public static void main(String[] args) {
//		
//		MemberOrClassLevaleVariable mb= new MemberOrClassLevaleVariable("Aishwarya");
//		mb.setSlary(2000);
//		mb.printInfo();
//	}
	
	
	public String name;
	private double price;
	
	public MemberOrClassLevaleVariable(String pname) {
		name=pname;
	}
	
	public void setPrice(double pprice) {
		price=pprice;
	}
	
	public void getInfo() {
		System.out.println("Name of product="+ name);
		System.out.println("Name of product="+ price);
	}
	
	public static void main(String[] args) {
		
		MemberOrClassLevaleVariable mb= new MemberOrClassLevaleVariable("Raju");
		mb.setPrice(1000);
		mb.getInfo();
	}
}


