package ScopeOfVariables;

public class StaticVariableScope {
	
//	private static double pivalue;
//	public static final String piconstant="pi";
//	
//	public static void main(String[] args) {
//		
//		pivalue=3.1456789;
//		
//		System.out.println("The value of  " + piconstant + " is " + pivalue);
//	}

	
	private static double pivalue;
	public static final String piconstant="pi";
	
	public static void main(String[] args) {
		
		pivalue=3.1456789;
		System.out.println("The value of " + piconstant + " is" + pivalue);
	}
}
