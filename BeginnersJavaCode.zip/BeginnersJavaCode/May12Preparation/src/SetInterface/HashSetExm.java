package SetInterface;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetExm {
	
	public static void main(String[] args) {
		
		HashSet<String> hs= new HashSet<String>();
		
		hs.add("Ravi");
		hs.add("Mohit");
		hs.add("Ravi");
		
		Iterator<String> itr= hs.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}

}
