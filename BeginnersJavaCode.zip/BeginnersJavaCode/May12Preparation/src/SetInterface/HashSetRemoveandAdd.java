package SetInterface;

import java.util.HashSet;

public class HashSetRemoveandAdd {
	
	public static void main(String[] args) {
		
		HashSet<String> hs= new HashSet<String>();
		
		hs.add("Ravi");
		hs.add("Vijay");
		hs.add("Kamran");
		hs.add("Arun");
		hs.add("Sumit");
		
		System.out.println("An intial list of elements: " + hs);
		hs.remove("Ravi");
		System.out.println("After remove list of elements: " + hs);
		
		HashSet<String> hs1= new HashSet<String>();
		hs1.add("Ajay");
		hs1.add("Gaurav");
		hs.addAll(hs1);
		System.out.println("Updated List : " + hs);
		
		hs.removeAll(hs1);
		System.out.println("After invoking removeAll method:" + hs);
		
		hs.clear();
		System.out.println("After invoking clear() method " + hs);
		
	}

}
