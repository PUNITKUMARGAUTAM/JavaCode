package SetInterface;

import java.util.LinkedHashSet;

public class LinkedHashSetExample {
	
	public static void main(String[] args) {
		
	
	
	LinkedHashSet<String> lhs= new LinkedHashSet<String>();
	
	lhs.add("Nagin");
	lhs.add("Nachger");
	lhs.add("Rajat");
	lhs.add("Saurabh");
	lhs.add("Mohit");
	
	System.out.println("HasSet list is =" + lhs);
	System.out.println(lhs.remove("Nachger"));
	System.out.println("After invoking remove elements"+ lhs);
	System.out.println(lhs.remove("for"));
	
	

}
}