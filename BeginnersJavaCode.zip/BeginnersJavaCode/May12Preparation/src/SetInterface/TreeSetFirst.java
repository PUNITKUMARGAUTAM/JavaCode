package SetInterface;

import java.util.TreeSet;

public class TreeSetFirst {
	
	public static void main(String[] args) {
		
		TreeSet<Integer> set= new TreeSet<Integer>();
		
		set.add(24);
		set.add(30);
		set.add(50);
		set.add(80);
		System.out.println("Lowest value = " + set.pollFirst());
		System.out.println("Highest value = " + set.pollLast());
		
		
	}

}
