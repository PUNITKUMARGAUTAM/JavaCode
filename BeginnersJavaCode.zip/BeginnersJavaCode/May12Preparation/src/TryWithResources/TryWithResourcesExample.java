package TryWithResources;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class TryWithResourcesExample {
	
//	public static void main(String[] args) throws IOException {
//		
//		try(InputStream inputStream = new FileInputStream("test.txt");
//				
//		Scanner scanner = new Scanner(inputStream)){
//			
//			while(scanner.hasNextLine()){
//				System.out.println(scanner.nextLine());
//			}
//		}
//		
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//		
//	}
	
	public static void main(String[] args)throws IOException {
		
		try(InputStream inputStream = new FileInputStream("test.txt");
				
				Scanner scanner = new Scanner(inputStream)){
			while(scanner.hasNextLine()) {
				System.out.println(scanner.nextLine());
				
			}
		}
		 
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}