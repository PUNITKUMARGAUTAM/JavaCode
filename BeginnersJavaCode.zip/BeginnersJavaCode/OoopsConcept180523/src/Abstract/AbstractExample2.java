package Abstract;


abstract class Bike{
	
	Bike() {
		System.out.println("Bike is created");
	}
	
	abstract void run();
	void changeGeared() {
		System.out.println("Geared changed");
	}
	
	
	
}

class Honda extends Bike{
	
	void run() {
		System.out.println("runing safely");
	}
}


public class AbstractExample2 {
	
	public static void main(String[] args) {
		
		Bike obj= new Honda();
		obj.run();
		obj.changeGeared();
	}
	
	
	

}
