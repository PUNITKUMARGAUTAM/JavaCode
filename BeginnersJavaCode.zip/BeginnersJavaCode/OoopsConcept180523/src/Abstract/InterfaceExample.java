package Abstract;

interface Banking{
	
	 float getRateOfIntrest();
}


class HYD implements Banking{
	
	public float getRateOfIntrest() {
		return 10.8f;
	}
}

class MP implements Banking{
	public float getRateOfIntrest() {
		return 12.6f;
	}
}
public class InterfaceExample {
	
	public static void main(String[] args) {
		
		Banking b= new MP();
		System.out.println("ROI==" + b.getRateOfIntrest());
		
		Banking c= new HYD();
		System.out.println("ROI==" + c.getRateOfIntrest());
	}

}
