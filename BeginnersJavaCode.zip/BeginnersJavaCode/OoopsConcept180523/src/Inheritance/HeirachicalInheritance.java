package Inheritance;


class Sports{
	
	void play(){
		System.out.println("playing");
	}
}

class Cricket extends Sports{
	
	void ball() {
		System.out.println("Ballingggg");
	}
}

class Hocky extends Sports{
	void goal() {
		System.out.println("Goal is imp");
	}
}

class Kabbadi extends Sports{
	void run() {
		System.out.println("runinggg");
	}
}
public class HeirachicalInheritance {
	
	public static void main(String[] args) {
		
		Kabbadi kb= new Kabbadi();
		kb.play();
		kb.run();
//		kb.ball() compilation error
		
	}

}
