package Inheritance;

class Man{
	
	void eat() {
		System.out.println("Father");
	}
	
}

class Woman extends Man{
	void bark() {
		System.out.println("Mother");
	}
}

class Children extends Woman{
	void weep() {
		System.out.println("Child");
	}
}
public class MultiLevalInheritance {

	public static void main(String[] args) {
		
		Children by= new Children();
        
		by.bark();
		by.eat();
		by.weep();
	}
}
