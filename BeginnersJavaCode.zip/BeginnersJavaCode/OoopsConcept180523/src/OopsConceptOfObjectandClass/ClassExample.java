package OopsConceptOfObjectandClass;


class Student {
	
	String name;
	int id;
}

public class ClassExample {
	
	public static void main(String[] args) {
		
		Student s= new Student();
		s.id= 12;
		s.name= "Sonu";
		
		Student s2= new Student();
		s2.id= 23;
		s2.name= "Rohit";
		
		System.out.println(s.id + "=" + s.name);
		
		System.out.println(s2.id  + "=" + s2.name);
	}

}







