package OopsConceptOfObjectandClass;

public class ConstructorEx {
	
	int id;
	String name;
	
    ConstructorEx(int i, String n){
    	id=i;
    	name=n;
    	
    	
    }
    
    void display() {
    	System.out.println(id   + "=" +  name);
    	
    }
    
    public static void main(String[] args) {
		
    	ConstructorEx cs= new ConstructorEx(1, "WTT");
    	ConstructorEx bs= new ConstructorEx(12, "Agra");
    	cs.display();
    	bs.display();
	}


}
