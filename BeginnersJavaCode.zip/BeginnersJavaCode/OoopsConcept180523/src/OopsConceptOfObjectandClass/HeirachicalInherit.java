package OopsConceptOfObjectandClass;

class Human {
	
	void hm(){
		
		System.out.println("The human is very minded");
		
	}
}

class Boy extends Human{
	
	void boy() {
		System.out.println("The human is boy ");
	}
}

class Young extends Human{
	
	void young() {
		System.out.println("The human is young");
		
	}
}

class Old extends Human{
	void old() {
		System.out.println("The human is old");
	}
}

public class HeirachicalInherit {
	
	public static void main(String[] args) {
		
		Old ol= new Old();
	
		ol.hm();
		ol.old();
		
	}

}
