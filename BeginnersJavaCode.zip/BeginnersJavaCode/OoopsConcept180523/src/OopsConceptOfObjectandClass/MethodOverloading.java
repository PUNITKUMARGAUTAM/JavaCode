package OopsConceptOfObjectandClass;


	
	

public class MethodOverloading {
	
	void sum(int a, int b) {
		System.out.println("int arg invoked");
	}
	
	void sum(long a , long b) {
		System.out.println("long arg invoked");
		
	}

	
	public static void main(String[] args) {
		
		MethodOverloading ml= new MethodOverloading();
		ml.sum(20, 20);
		ml.sum(20l, 20l);
		
		
	}

}


class Adder {
	
	static int add(int a, int b) {
		return a+b;
	}
	
	static long add(int a, int b, int c) {
		return a+b+c;
	}
	
	class LOading {
		
		public static void main(String[] args) {
			
			System.out.println(Adder.add(10, 20));
			System.out.println(Adder.add(12, 23,30));
		}
	}
	
}
