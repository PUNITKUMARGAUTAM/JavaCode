package OopsConceptOfObjectandClass;


class MiniCamputer{
	
	void mc() {
		System.out.println("very old time using mcomputer ");
	}
}

class Computer extends MiniCamputer{
	 void cm() {
		 System.out.println("after using computer");
	 }
}

class Laptop extends Computer{
	
	void lappy() {
		System.out.println("Currently using laptop");
	}
}

public class MultiLevelInherit {
	
	public static void main(String[] args) {
		
		Laptop lp= new Laptop();
		lp.mc();
		lp.cm();
		lp.lappy();
		
	}

}
