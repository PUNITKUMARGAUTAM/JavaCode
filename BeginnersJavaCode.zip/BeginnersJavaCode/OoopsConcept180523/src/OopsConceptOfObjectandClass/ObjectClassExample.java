package OopsConceptOfObjectandClass;


class Account{
//	
//	int accno;
//	String name;
//	float amount;
//	
//
//  void insert(int acno, String n, float amt){
//	  
//	 accno=acno;
//	 name=n;
//	 amount=amt;
//	 
// }
//  
//  void deposite(float amt) {
//	  amount=amount+amt;{
//		  System.out.println(amt + "Deposited");
//		  
//	  }
//  }
//  
//  void withdraw(float amt) {
//	  if(amount<amt) {
//		  System.out.println("Insufficient balance");
//	  }
//	  
//	  else {
//		  amount=amount-amt;
//		  System.out.println(amt + "Withdraw");
//	  }
//	  
//	 }
//  void checkBalance() {
//	  System.out.println("Balance is " + amount);
//  }
//  
//  void dispaly() {
//	  System.out.println(amount + "" + name + "" + accno);
//  }
//
//
//public class ObjectClassExample {
//	
//	public static void main(String[] args) {
//		
//		Account ac=new Account();
//		ac.insert(011, "Yadav" , 5000);
//		
//		ac.dispaly();
//		
//		ac.deposite(2000);
//		
//		ac.withdraw(500);
//		
//		ac.checkBalance();
//	}
//
//}
	
	
}