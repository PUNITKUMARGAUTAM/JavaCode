package OopsConceptOfObjectandClass;


class Mobile{
	
   void phoneCall() {
	   System.out.println("Calling through the mobile");
   }

}
 class Apple  extends Mobile{
	
	void talk() {
		System.out.println("Talking through the mobile");
	}
 }
    class SingleInherit{
	   
	   public static void main(String[] args) {
		
	
		Apple ap= new Apple();
		ap.phoneCall();
		ap.talk();
}
    }
