package OopsConceptOfObjectandClass;


class Lappy{
	
	int id;
	String name;
	static String system = "Lenovo";


Lappy(int i, String n){
	
	id=i;
	name=n;
	
}

void display() {
	System.out.println(id  + name + system);
}
}
public class StaticEx {
	
	
	public static void main(String[] args) {
		
		Lappy lp= new Lappy(12,"Laptop");
		Lappy lp1= new Lappy(12,"HP");
		
		lp.display();
		lp1.display();
	}

}
