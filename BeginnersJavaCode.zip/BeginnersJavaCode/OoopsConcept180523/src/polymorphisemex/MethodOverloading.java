package polymorphisemex;

public class MethodOverloading {
	
	void sum(int a, int b) {
		System.out.println(a+b);
	}
	
	void sum(int a, int b , int c) {
		System.out.println(a+b+c);
	}
	
	public static void main(String[] args) {
		
		MethodOverloading mo = new MethodOverloading();
		
		mo.sum(10, 20);
		mo.sum(20, 20,20);
	}

}
