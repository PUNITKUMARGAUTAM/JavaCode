package polymorphisemex;

class Bank{
	int getRateIntrestOf() {
		return 0;
	}
}

class ICICI extends Bank{
	int getRateIntrestOf() {
		return 9;
	}
}

class UBI extends Bank{
	int getRateIntrestOf(){
		return 10;
	}
}

class AXIS extends Bank{  
int getRateIntrestOf()
{
	return 11;}  
} 

public class OverridingExample {
	
	public static void main(String[] args) {
		
		AXIS ax= new AXIS();
		ICICI ic= new ICICI();
		UBI ub= new UBI();
		
		
		System.out.println("Intrest of axis="+ ax.getRateIntrestOf());
		System.out.println("Intrest of icici="+ ic.getRateIntrestOf());
		System.out.println("Intrest of ubi="+ ub.getRateIntrestOf());
		
		
	}

}
