package StreamWorldPackage;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MapAndFlatMapOperation {
	
	public static void main(String[] args) {
		
		Map<String, List<String>> personnameANdPhonesMap= new HashMap();
		
		personnameANdPhonesMap.put("PK", Arrays.asList("9865434567"));
		personnameANdPhonesMap.put("Ajeet", Arrays.asList("9845676678"));
		personnameANdPhonesMap.put("Aishwarya", Arrays.asList("9745667382"));
		personnameANdPhonesMap.put("Amit", Arrays.asList("8745763523"));
		
		//Use of flatMap get all phones
		System.out.println("<==========Use of flatMap stream  for get all phones==========>");
		
		List<String> phones= personnameANdPhonesMap.values().stream().flatMap(Collection::stream).collect(Collectors.toList());
		System.out.println(phones);
		
		System.out.println("<==========Use of Map stream  for get all phones==========>");
		List<Stream<String>> personPhones= personnameANdPhonesMap.values().stream().map(Collection::stream).collect(Collectors.toList());
		
		personPhones.forEach((pPhones)->{;
		
		List<String> perPhones=pPhones.collect(Collectors.toList());
	    System.out.println(perPhones);
		});
	}

}
