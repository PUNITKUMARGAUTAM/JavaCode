package StreamWorldPackage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class StreamFirst {
	
	public static void main(String[] args) {
		
		IntStream.of(1,2,3,4,5,6,7).forEach(System.out::println);
		
		System.out.println("*********************");
		
		List<Integer> numberlist=Arrays.asList(2,4,5,6,7,8,9,5);
		
		List<Integer> squareLits= numberlist.stream().map(n-> n*n).distinct().collect(Collectors.toList());
		squareLits.forEach(System.out::println);
		
		System.out.println("*********************");
		
		List<String> nameList= new ArrayList<String>();
		nameList.add("John");
		nameList.add("Sumit");
		nameList.add("");
		nameList.add("Akash");
		nameList.add("World");
		nameList.add("");
		nameList.add("Jivan");
		nameList.add("Amrit");
		nameList.add("");
		nameList.add("");
		
		long count = nameList.stream().filter(name-> name.isEmpty()).count();
		System.out.println("Number of string element= "+ count);
				
		System.out.println("*********************");
		// print 5 table 
		IntStream.iterate(5, n->n+5).limit(10).forEach(System.out::println);
		
		
		System.out.println("Ascending number list");
		numberlist.stream().sorted().forEach(System.out::println);
		
		System.out.println("Descending number list");
		numberlist.stream().sorted((n1,n2)->n2.compareTo(n1)).forEach(System.out::println);
		
		
		nameList.stream().filter(name-> !name.isEmpty()).collect(Collectors.toList()).forEach(System.out::println);
		
		String combineName= nameList.stream().filter(name-> !name.isEmpty()).collect(Collectors.joining(" "));
	    System.out.println(combineName);
		
		System.out.println("*********************");
		
		IntSummaryStatistics summaryStatistics=numberlist.stream().mapToInt(number->number).summaryStatistics();
		System.out.println(summaryStatistics.getAverage());
		System.out.println(summaryStatistics.getMax());
		System.out.println(summaryStatistics.getMin());
		System.out.println(summaryStatistics.getSum());
		System.out.println(summaryStatistics.getCount());
		
	}
    
}
