package StreamWorldPackage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StreamGroupingBy {
	
	public static void main(String[] args) {
		
		List<Person> person= new ArrayList<>();
		
		person.add(new Person("Ajeet","India",25));
		person.add(new Person("Manjeet","Seria",24));
		person.add(new Person("Deepak","India",30));
		person.add(new Person("Rahul","India",27));
		person.add(new Person("Aakash","Pak",30));
		person.add(new Person("Vikash","Pak",34));
		person.add(new Person("Rohit","India",29));
		
//		Map<String, List<Person>> groupByCity= person.stream().collect(Collectors.groupingBy(Person:: getCountry));
//		System.out.println(groupByCity);
		
//		output== {Seria=[Person [name=Manjeet, country=Seria, age=24]], Pak=[Person [name=Aakash, country=Pak, age=30], Person [name=Vikash, country=Pak, age=34]], India=[Person [name=Ajeet, country=India, age=25], Person [name=Deepak, country=India, age=30], Person [name=Rahul, country=India, age=27], Person [name=Rohit, country=India, age=29]]}
		
		Map<String, List<Person>> groupByCity= person.stream().collect(Collectors.groupingBy(Person:: getCountry));
		groupByCity.forEach((country,persons)->{
			System.out.println(country);
			System.out.println(persons);
		});
		
		Map<Integer, List<Person>> groupByAge= person.stream().collect(Collectors.groupingBy(Person::getAge));
		groupByAge.forEach((age,persons)->{
			System.out.println(age);
			System.out.println(persons);
		});
	}

}
