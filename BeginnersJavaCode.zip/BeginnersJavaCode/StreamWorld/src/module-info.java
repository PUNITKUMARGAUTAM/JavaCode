module StreamWorld {
}